import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  ArrowLeft, 
  AlertCircle, 
  Scissors, 
  CheckCircle2,
  KeyRound
} from 'lucide-react';

export const AdminLogin: React.FC = () => {
  const { loginAdmin, navigate } = useShop();

  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('MarutiAdmin@2026');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const success = await loginAdmin(username, password);
      if (!success) {
        setError('Invalid admin credentials. Please verify your username and password.');
      }
    } catch (err) {
      setError('An error occurred during authentication. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      const success = await loginAdmin('admin', 'MarutiAdmin@2026');
      if (!success) {
        setError('Login failed. Please check credentials.');
      }
    } catch {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#151515] flex flex-col justify-center py-12 sm:px-6 lg:px-8 selection:bg-[#C8A96B]/30 selection:text-white">
      <div className="sm:mx-auto sm:w-full sm:max-w-md px-4">
        {/* Brand Header */}
        <div className="text-center">
          <div className="w-14 h-14 rounded-2xl bg-[#111111] border border-[#2B2B2B] text-[#C8A96B] flex items-center justify-center mx-auto shadow-lg mb-3">
            <Scissors className="w-7 h-7 -rotate-45" />
          </div>
          <h2 className="text-2xl font-black text-white tracking-wide font-serif">
            SHREE MARUTI KRUPA
          </h2>
          <p className="mt-1 text-xs uppercase tracking-widest text-[#C8A96B] font-bold">
            Store Owner & Merchant Portal
          </p>
          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#111111] border border-[#2B2B2B] text-[#D9D4CA] text-xs">
            <Lock className="w-3 h-3 text-[#C8A96B]" />
            <span>Secure Merchant Access • Protected</span>
          </div>
        </div>

        {/* 1-Tap Quick Login Card */}
        <div className="mt-6 bg-[#111111] border border-[#2B2B2B] rounded-2xl p-4 shadow-lg text-center space-y-2">
          <p className="text-xs font-bold text-[#D9D4CA] flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#C8A96B]" />
            <span>Fast Access: One-tap login without typing</span>
          </p>
          <button
            type="button"
            onClick={handleQuickLogin}
            disabled={loading}
            className="w-full bg-[#1E1E1E] hover:bg-[#2B2B2B] border border-[#C8A96B]/50 text-white font-black py-3 px-4 rounded-xl text-sm transition shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
          >
            <span className="text-[#C8A96B]">⚡</span>
            <span>1-Tap Instant Admin Login</span>
          </button>
          <p className="text-[11px] text-[#777777]">
            Instantly opens dashboard as administrator (<strong className="text-white">admin</strong>)
          </p>
        </div>

        {/* Login Box */}
        <div className="mt-4 bg-[#111111] border border-[#2B2B2B] rounded-2xl p-6 sm:p-8 shadow-2xl">
          <div className="text-center pb-3 border-b border-[#2B2B2B] mb-4">
            <span className="text-xs text-[#777777] uppercase tracking-wider font-bold">
              Or Sign In with Password
            </span>
          </div>

          {error && (
            <div className="mb-5 bg-[#9B2C2C]/20 border border-[#9B2C2C]/40 rounded-xl p-3 text-xs text-[#D9D4CA] flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-[#9B2C2C] shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#D9D4CA] uppercase tracking-wider mb-1.5">
                Admin Username
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#777777]">
                  <User className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white text-sm focus:outline-none focus:ring-1 focus:ring-[#C8A96B] font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D9D4CA] uppercase tracking-wider mb-1.5">
                Admin Password
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#777777]">
                  <KeyRound className="w-4 h-4" />
                </span>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white text-sm focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
                />
              </div>
            </div>

            {/* Merchant Initial Credentials Notice */}
            <div className="bg-[#1E1E1E] border border-[#2B2B2B] p-3 rounded-xl text-[11px] text-[#777777] space-y-1">
              <p className="font-semibold text-[#C8A96B] flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Default Credentials:
              </p>
              <p className="text-[#D9D4CA] font-mono text-[11px]">
                User: <span className="text-white font-bold">admin</span> | Pass: <span className="text-white font-bold">MarutiAdmin@2026</span>
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 bg-[#1E1E1E] hover:bg-[#2B2B2B] border border-[#2B2B2B] hover:border-[#C8A96B]/50 text-white font-bold py-3 px-4 rounded-xl text-sm transition shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <span>Verifying Authorization...</span>
              ) : (
                <>
                  <Lock className="w-4 h-4 text-[#C8A96B]" />
                  <span>Sign In as Admin</span>
                </>
              )}
            </button>
          </form>

          {/* Back to Customer Store */}
          <div className="mt-6 pt-5 border-t border-[#2B2B2B] text-center">
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C8A96B] hover:text-white transition cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>← Back to Customer Storefront</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

