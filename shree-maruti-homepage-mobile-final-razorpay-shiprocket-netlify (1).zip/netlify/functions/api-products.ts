import { getStore } from '@netlify/blobs';

const store = getStore('smk-products');

const INITIAL_PRODUCTS = [
[
  {
    "id": "smk-01",
    "name": "Raymond 100% Giza Cotton Pure White Shirt Fabric",
    "nameHi": "रेमंड 100% गीज़ा कॉटन शुद्ध सफेद शर्ट का कपड़ा",
    "category": "shirt",
    "brand": "Raymond Classic",
    "originalPrice": 1299,
    "discountPrice": 699,
    "discountPercent": 46,
    "rating": 4.9,
    "reviewCount": 428,
    "image": "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "Ultra-smooth premium 100% Egyptian Giza Cotton shirting fabric. Breathable, sweat-absorbent, and maintains a crisp formal luster all day.",
    "material": "100% Egyptian Giza Cotton",
    "feel": "Silky smooth, lightweight & breathable",
    "weave": "Fine Twill Weave with subtle sheen",
    "defaultLength": "2.25m Shirt Cut",
    "totalStock": 100,
    "lengthOptions": [
      {
        "lengthMeters": 2.25,
        "label": "2.25m - Standard Shirt / Kurta Cut",
        "suitableFor": "Full Sleeve Shirt or Kurta (Single Cut)",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-01",
        "colorName": "Standard",
        "hex": "#FFFFFF",
        "image": "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80",
        "stock": 100
      }
    ],
    "isBestSeller": true,
    "isNewArrival": false,
    "isOffer": true,
    "inStock": true,
    "updatedAt": "2026-10-07T11:44:01.419Z"
  },
  {
    "id": "smk-02",
    "name": "Siyaram Poly-Viscose Formal Pant / Trouser Fabric",
    "nameHi": "सियाराम फॉर्मल पैंट / ट्राउजर फैब्रिक",
    "category": "pant",
    "brand": "Siyaram's",
    "originalPrice": 999,
    "discountPrice": 549,
    "discountPercent": 45,
    "rating": 4.8,
    "reviewCount": 312,
    "image": "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "Wrinkle-resistant poly-viscose trouser fabric with sharp crease retention. Perfect for everyday office wear, meetings, and formal occasions.",
    "material": "70% Polyester, 30% Viscose (Wrinkle-Free)",
    "feel": "Medium weight, firm drape & sharp crease",
    "weave": "Gabardine Weave",
    "defaultLength": "1.20m Pant Cut",
    "totalStock": 155,
    "lengthOptions": [
      {
        "lengthMeters": 1.2,
        "label": "1.20m - Standard Pant / Trouser Cut",
        "suitableFor": "Regular Fit Formal Trouser (Up to 40 waist)",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-02",
        "colorName": "Standard",
        "hex": "#374151",
        "image": "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80",
        "stock": 155
      }
    ],
    "isBestSeller": true,
    "isNewArrival": false,
    "isOffer": true,
    "inStock": true
  },
  {
    "id": "smk-03",
    "name": "Royal Heritage Shirt + Pant Gift Combo Set",
    "nameHi": "रॉयल हेरिटेज शर्ट + पैंट जोड़ी कॉम्बो सेट",
    "category": "combo",
    "brand": "Maruti Krupa Special",
    "originalPrice": 2199,
    "discountPrice": 1199,
    "discountPercent": 45,
    "rating": 4.9,
    "reviewCount": 560,
    "image": "/src/assets/images/hero_model_portrait_1790689718903.jpg",
    "additionalImages": [
      "/src/assets/images/model_fabric_close_1790689755678.jpg",
      "/src/assets/images/hero_model_banner_1790689738433.jpg"
    ],
    "description": "Perfect matching pair! 2.25m premium shirt fabric paired with 1.20m high-durability matching formal trouser fabric in an attractive gift box packing.",
    "material": "Cotton Shirting + Terry-Rayon Suiting",
    "feel": "Luxurious gift-ready texture & comfort",
    "weave": "Complementary Fine Herringbone & Matte Trouser",
    "defaultLength": "Combo: 2.25m Shirt + 1.20m Pant",
    "totalStock": 96,
    "lengthOptions": [
      {
        "lengthMeters": 3.45,
        "label": "Combo: 2.25m Shirt + 1.20m Pant",
        "suitableFor": "Complete Matching Set (2.25m Shirt Piece + 1.20m Pant Piece)",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-03",
        "colorName": "Standard",
        "hex": "#2563EB",
        "image": "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=800&q=80",
        "stock": 96
      }
    ],
    "isBestSeller": true,
    "isNewArrival": false,
    "isOffer": true,
    "inStock": true
  },
  {
    "id": "smk-04",
    "name": "Pure 60 Lea Linen Luxury Shirt Fabric - Natural Cool",
    "nameHi": "प्योर 60 ली लिनेन लक्जरी शर्ट फैब्रिक",
    "category": "shirt",
    "brand": "Linen Club Edition",
    "originalPrice": 2499,
    "discountPrice": 1499,
    "discountPercent": 40,
    "rating": 4.85,
    "reviewCount": 198,
    "image": "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "Pure 100% natural European flax linen. Keeps body 3 to 4 degrees cooler in hot climates. Renowned for its rich texture and natural grace.",
    "material": "100% Pure Flax Linen (60 Lea Count)",
    "feel": "Crisp, airy, breathable & softens with every wash",
    "weave": "Natural Slub Linen Weave",
    "defaultLength": "2.25m Shirt Cut",
    "totalStock": 57,
    "lengthOptions": [
      {
        "lengthMeters": 2.25,
        "label": "2.25m - Luxury Linen Shirt / Kurta Cut",
        "suitableFor": "Full Sleeve Linen Shirt or Royal Kurta",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-04",
        "colorName": "Standard",
        "hex": "#A3B899",
        "image": "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80",
        "stock": 57
      }
    ],
    "isBestSeller": false,
    "isNewArrival": true,
    "isOffer": false,
    "inStock": true
  },
  {
    "id": "smk-05",
    "name": "Arvind Mills Micro-Check Executive Cotton Shirt Fabric",
    "nameHi": "अरविंद मिल्स माइक्रो-चेक कॉटन शर्ट का कपड़ा",
    "category": "shirt",
    "brand": "Arvind Mills",
    "originalPrice": 1199,
    "discountPrice": 629,
    "discountPercent": 47,
    "rating": 4.75,
    "reviewCount": 186,
    "image": "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "Subtle micro-check pattern woven with mercerised combed cotton yarns. Perfect for corporate interviews, daily office styling, and clean elegance.",
    "material": "100% Combed Compact Cotton",
    "feel": "Light, crisp and easy to iron",
    "weave": "Micro-Check Yarn Dyed Weave",
    "defaultLength": "2.25m Shirt Cut",
    "totalStock": 60,
    "lengthOptions": [
      {
        "lengthMeters": 2.25,
        "label": "2.25m - Executive Shirt / Kurta Cut",
        "suitableFor": "Full Sleeve Office Shirt or Kurta",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-05",
        "colorName": "Standard",
        "hex": "#1E3A8A",
        "image": "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80",
        "stock": 60
      }
    ],
    "isBestSeller": false,
    "isNewArrival": true,
    "isOffer": true,
    "inStock": true
  },
  {
    "id": "smk-06",
    "name": "Digjam Super 120s Blazer + Trouser Combo Fabric",
    "nameHi": "डिग्जाम सुपर 120s ब्लेजर व पैंट कॉम्बो फैब्रिक",
    "category": "combo",
    "brand": "Digjam Premium",
    "originalPrice": 2899,
    "discountPrice": 1699,
    "discountPercent": 41,
    "rating": 4.95,
    "reviewCount": 140,
    "image": "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "Impeccable wool-rich handfeel crafted with modern micro-fiber technology. Includes 2.25m blazer/coat cut + 1.20m matching luxury trouser piece.",
    "material": "Poly-Wool Blend (Super 120s Touch)",
    "feel": "Rich, supple, royal fall and drape",
    "weave": "Royal Matt Suiting",
    "defaultLength": "Combo: 2.25m Shirt + 1.20m Pant",
    "totalStock": 43,
    "lengthOptions": [
      {
        "lengthMeters": 3.45,
        "label": "Combo: 2.25m Blazer/Shirt + 1.20m Pant",
        "suitableFor": "2.25m Top Piece + 1.20m Trouser Piece",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-06",
        "colorName": "Standard",
        "hex": "#0F172A",
        "image": "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
        "stock": 43
      }
    ],
    "isBestSeller": true,
    "isNewArrival": false,
    "isOffer": false,
    "inStock": true
  },
  {
    "id": "smk-07",
    "name": "Raymond Khaki Chino Cotton Pant Fabric",
    "nameHi": "रेमंड खाकी कॉटन चीनो पैंट फैब्रिक",
    "category": "pant",
    "brand": "Raymond Cotton Casuals",
    "originalPrice": 1199,
    "discountPrice": 649,
    "discountPercent": 45,
    "rating": 4.8,
    "reviewCount": 220,
    "image": "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "Heavyweight cotton twill with comfortable 2% Lycra stretch. 1.20m cut ideal for stitching modern flat-front chinos and comfortable daily office pants.",
    "material": "98% Cotton, 2% Spandex Stretch",
    "feel": "Sturdy, soft touch with slight stretch comfort",
    "weave": "Heavy Cotton Twill",
    "defaultLength": "1.20m Pant Cut",
    "totalStock": 72,
    "lengthOptions": [
      {
        "lengthMeters": 1.2,
        "label": "1.20m - Standard Chino Pant Cut",
        "suitableFor": "Regular Fit Chino / Pant (Up to 40 waist)",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-07",
        "colorName": "Standard",
        "hex": "#D4B996",
        "image": "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=800&q=80",
        "stock": 72
      }
    ],
    "isBestSeller": false,
    "isNewArrival": true,
    "isOffer": true,
    "inStock": true
  },
  {
    "id": "smk-08",
    "name": "Maruti Krupa All-Weather Safari Suit Fabric Combo",
    "nameHi": "मारुति कृपा ऑल-वेदर सफारी सूट कपड़ा कॉम्बो",
    "category": "combo",
    "brand": "Maruti Krupa Special",
    "originalPrice": 2299,
    "discountPrice": 1249,
    "discountPercent": 45,
    "rating": 4.9,
    "reviewCount": 395,
    "image": "https://images.unsplash.com/photo-1593030761757-71fae45fa0e7?auto=format&fit=crop&w=800&q=80",
    "additionalImages": [
      "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=800&q=80"
    ],
    "description": "High dignity, classic Indian Safari suit fabric. Cut gives 2.25m for safari bush shirt and 1.20m for matching formal safari pant.",
    "material": "Premium Poly-Viscose Matty Weave",
    "feel": "Durable, dignified fall and easy maintenance",
    "weave": "Safari Matty Weave",
    "defaultLength": "Combo: 2.25m Shirt + 1.20m Pant",
    "totalStock": 80,
    "lengthOptions": [
      {
        "lengthMeters": 3.45,
        "label": "Combo: 2.25m Bush Shirt + 1.20m Safari Pant",
        "suitableFor": "Full Safari Combo Set (2.25m Shirt + 1.20m Pant)",
        "priceMultiplier": 1
      }
    ],
    "variants": [
      {
        "id": "v-std-08",
        "colorName": "Standard",
        "hex": "#E2D4B7",
        "image": "https://images.unsplash.com/photo-1593030761757-71fae45fa0e7?auto=format&fit=crop&w=800&q=80",
        "stock": 80
      }
    ],
    "isBestSeller": true,
    "isNewArrival": false,
    "isOffer": true,
    "inStock": true
  }
]
];

async function getProducts(): Promise<any[]> {
  const products = await store.get('catalog', { type: 'json' }) as any[] | null;
  if (Array.isArray(products)) return products;
  await store.setJSON('catalog', INITIAL_PRODUCTS);
  return INITIAL_PRODUCTS;
}

export default async (req: Request, context: any) => {
  try {
    const method = req.method.toUpperCase();
    const id = context?.params?.id || '';
    let products = await getProducts();

    if (method === 'GET') {
      return new Response(JSON.stringify({ success: true, count: products.length, products }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (method === 'DELETE') {
      if (!id) {
        return new Response(JSON.stringify({ success: false, error: 'Product id is required' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
      }
      const exists = products.some((p: any) => p.id === id);
      if (!exists) {
        return new Response(JSON.stringify({ success: false, error: 'Product not found' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
      }
      products = products.filter((p: any) => p.id !== id);
      await store.setJSON('catalog', products);
      return new Response(JSON.stringify({ success: true, id, message: 'Product deleted successfully' }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (method === 'POST') {
      const product = await req.json();
      if (!product?.id || !product?.name) {
        return new Response(JSON.stringify({ success: false, error: 'Invalid product data' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
      }
      const now = new Date().toISOString();
      const idx = products.findIndex((p: any) => p.id === product.id);
      if (idx >= 0) products[idx] = { ...products[idx], ...product, updatedAt: now };
      else products.unshift({ ...product, createdAt: now, updatedAt: now });
      await store.setJSON('catalog', products);
      return new Response(JSON.stringify({ success: true, product: idx >= 0 ? products[idx] : products[0] }), { headers: { 'Content-Type': 'application/json' } });
    }

    if (method === 'PUT') {
      if (!id) return new Response(JSON.stringify({ success: false, error: 'Product id is required' }), { status: 400, headers: { 'Content-Type': 'application/json' } });
      const rawProduct = await req.json();
      const idx = products.findIndex((p: any) => p.id === id);
      if (idx === -1) return new Response(JSON.stringify({ success: false, error: 'Product not found' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
      products[idx] = { ...products[idx], ...rawProduct, updatedAt: new Date().toISOString() };
      await store.setJSON('catalog', products);
      return new Response(JSON.stringify({ success: true, product: products[idx] }), { headers: { 'Content-Type': 'application/json' } });
    }

    return new Response(JSON.stringify({ success: false, error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json', 'Allow': 'GET, POST, PUT, DELETE' }
    });
  } catch (error) {
    console.error('Products API error:', error);
    return new Response(JSON.stringify({ success: false, error: 'Failed to process products request' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};
