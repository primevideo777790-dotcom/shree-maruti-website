import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { Product, ProductVariant, FabricLengthOption } from '../../types';
import { X, Plus, Trash2, Scissors, Check } from 'lucide-react';
import { ProductImageUploader } from './ProductImageUploader';

interface AdminAddProductModalProps {
  onClose: () => void;
}

const FABRIC_SIZES = [
  {
    id: 'combo',
    size: '2.25m × 1.20m',
    lengthMeters: 3.45,
    label: '2.25m × 1.20m',
    suitableFor: 'Shirt (2.25m) + Pant (1.20m) Combo Set',
    priceMultiplier: 1.0
  },
  {
    id: 'shirt',
    size: '2.25m',
    lengthMeters: 2.25,
    label: '2.25m',
    suitableFor: 'Full Sleeve Shirt / Kurta Cut',
    priceMultiplier: 1.0
  },
  {
    id: 'pant',
    size: '1.20m',
    lengthMeters: 1.20,
    label: '1.20m',
    suitableFor: 'Formal Trouser / Pant Cut',
    priceMultiplier: 1.0
  }
];

export const AdminAddProductModal: React.FC<AdminAddProductModalProps> = ({ onClose }) => {
  const { addProduct } = useShop();

  const [name, setName] = useState('');
  const [nameHi, setNameHi] = useState('');
  const [category, setCategory] = useState<'shirt' | 'pant' | 'combo' | 'premium'>('shirt');
  const [brand, setBrand] = useState("Siyaram's");
  const [originalPrice, setOriginalPrice] = useState(1299);
  const [discountPrice, setDiscountPrice] = useState(699);
  const [material, setMaterial] = useState('100% Egyptian Giza Cotton');
  const [feel, setFeel] = useState('Ultra Soft & Breathable');
  const [weave, setWeave] = useState('Fine Satin Weave');
  const [description, setDescription] = useState('Premium tailor-quality unstitched fabric, perfect for festive wear and formal suiting.');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80');
  const [additionalImages, setAdditionalImages] = useState<string[]>([]);
  const [totalStock, setTotalStock] = useState<number>(100);

  // Dynamic fabric size options (1. 2.25m × 1.20m, 2. 2.25m, 3. 1.20m)
  const [selectedSizes, setSelectedSizes] = useState<string[]>(['2.25m × 1.20m', '2.25m', '1.20m']);

  const toggleSize = (size: string) => {
    if (selectedSizes.includes(size)) {
      if (selectedSizes.length === 1) {
        alert('Please select at least one fabric size option.');
        return;
      }
      setSelectedSizes(selectedSizes.filter((s) => s !== size));
    } else {
      setSelectedSizes([...selectedSizes, size]);
    }
  };

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (!imageUrl) {
      alert('Please upload at least one product image.');
      return;
    }

    if (selectedSizes.length === 0) {
      alert('Please select at least one fabric size option.');
      return;
    }

    const discountPercent = Math.round(((originalPrice - discountPrice) / originalPrice) * 100);

    const lengthOptions: FabricLengthOption[] = selectedSizes.map((sizeStr) => {
      const found = FABRIC_SIZES.find((s) => s.size === sizeStr);
      return {
        lengthMeters: found ? found.lengthMeters : 2.25,
        label: sizeStr,
        suitableFor: found ? found.suitableFor : 'Standard Fabric Cut',
        priceMultiplier: 1.0
      };
    });

    const newProd: Product = {
      id: `smk-prod-${Date.now()}`,
      name: name.trim(),
      nameHi: nameHi.trim() || name.trim(),
      category,
      brand: brand.trim() || "Shree Maruti Krupa",
      originalPrice,
      discountPrice,
      discountPercent: discountPercent > 0 ? discountPercent : 25,
      rating: 4.8,
      reviewCount: 42,
      image: imageUrl,
      additionalImages: additionalImages.length > 0 ? additionalImages : undefined,
      description,
      material,
      feel,
      weave,
      defaultLength: selectedSizes.join(', '),
      totalStock,
      lengthOptions,
      variants: [
        { id: `v-${Date.now()}`, colorName: 'Standard', hex: '#333333', stock: totalStock, image: imageUrl }
      ],
      isNewArrival: true,
      inStock: true
    };

    setIsSubmitting(true);
    try {
      const ok = await addProduct(newProd);
      if (ok) {
        onClose();
      } else {
        alert('Failed to save fabric. Please check the image upload/server connection and try again.');
      }
    } catch (err) {
      console.error('Error saving product:', err);
      alert('Failed to save product to backend database. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl max-w-2xl w-full my-auto overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2B2B2B] bg-[#151515] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1E1E1E] text-[#C8A96B] border border-[#2B2B2B] flex items-center justify-center">
              <Scissors className="w-4 h-4 -rotate-45" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                Add New Fabric Product
              </h2>
              <p className="text-xs text-[#777777]">Instantly publishes to live customer store</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg bg-[#1E1E1E] hover:bg-[#2B2B2B] text-[#D9D4CA] border border-[#2B2B2B] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs text-[#D9D4CA]">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#D9D4CA] mb-1">Fabric Name (English) *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Siyaram's Royal Formal Trouser Fabric"
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#D9D4CA] mb-1">Fabric Name (Hindi) *</label>
              <input
                type="text"
                required
                value={nameHi}
                onChange={(e) => setNameHi(e.target.value)}
                placeholder="e.g. सियाराम रॉयल फॉर्मल पैंट फैब्रिक"
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-[#D9D4CA] mb-1">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              >
                <option value="shirt">Shirt Fabric</option>
                <option value="pant">Pant Fabric</option>
                <option value="combo">Shirt + Pant Combo</option>
                <option value="premium">Premium Suiting</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#D9D4CA] mb-1">Brand Name *</label>
              <input
                type="text"
                required
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="e.g. Siyaram's, Raymond, Giza"
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#D9D4CA] mb-1">Material Composition</label>
              <input
                type="text"
                value={material}
                onChange={(e) => setMaterial(e.target.value)}
                placeholder="e.g. 100% Pure Linen"
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>
          </div>

          {/* Pricing */}
          <div className="grid grid-cols-2 gap-3 bg-[#151515] p-3.5 rounded-xl border border-[#2B2B2B]">
            <div>
              <label className="block font-bold text-[#D9D4CA] mb-1">Original Price / MRP (₹)</label>
              <input
                type="number"
                required
                value={originalPrice}
                onChange={(e) => setOriginalPrice(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#C8A96B] mb-1">Discount Price (₹ Selling Rate)</label>
              <input
                type="number"
                required
                value={discountPrice}
                onChange={(e) => setDiscountPrice(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>
          </div>

          {/* Product Images (Upload & Gallery) */}
          <ProductImageUploader
            primaryImage={imageUrl}
            additionalImages={additionalImages}
            onChange={(primary, additionals) => {
              setImageUrl(primary);
              setAdditionalImages(additionals);
            }}
          />

          {/* Dynamic Fabric Size Selection (1. 2.25m × 1.20m, 2. 2.25m, 3. 1.20m) */}
          <div className="space-y-3 pt-3 border-t border-[#2B2B2B]">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white block uppercase tracking-wider text-[11px]">
                Product Size Selection (Select one or multiple)
              </span>
              <span className="text-[#C8A96B] font-bold text-[11px] bg-[#151515] px-2.5 py-0.5 rounded border border-[#2B2B2B]">
                {selectedSizes.length} Size{selectedSizes.length > 1 ? 's' : ''} Selected
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {FABRIC_SIZES.map((item) => {
                const isSelected = selectedSizes.includes(item.size);
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => toggleSize(item.size)}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition flex flex-col justify-between ${
                      isSelected
                        ? 'border-[#C8A96B] bg-[#1E1E1E] text-white shadow-xs ring-1 ring-[#C8A96B]/50'
                        : 'border-[#2B2B2B] bg-[#151515] text-[#777777] hover:border-[#4A4A4A]'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <span className={`font-mono font-bold text-xs ${isSelected ? 'text-white' : 'text-[#777777]'}`}>
                        {item.size}
                      </span>
                      <div className={`w-4 h-4 rounded flex items-center justify-center border ${
                        isSelected 
                          ? 'bg-[#C8A96B] border-[#C8A96B] text-[#111111]' 
                          : 'border-[#4A4A4A] bg-[#1E1E1E]'
                      }`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>
                    <span className="text-[10px] text-[#777777] line-clamp-2">
                      {item.suitableFor}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Total Fabric Stock (in meters) */}
            <div className="pt-2">
              <label className="block font-bold text-[#D9D4CA] text-xs mb-1">
                Available Roll Stock (in Meters)
              </label>
              <input
                type="number"
                min="1"
                required
                value={totalStock}
                onChange={(e) => setTotalStock(Number(e.target.value))}
                placeholder="e.g. 100 meters"
                className="w-full px-3 py-2 bg-[#1E1E1E] border border-[#2B2B2B] rounded-xl text-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-[#C8A96B]"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-[#2B2B2B] flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-[#1E1E1E] text-[#D9D4CA] border border-[#2B2B2B] font-bold hover:bg-[#2B2B2B] cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 rounded-xl bg-[#1E1E1E] hover:bg-[#2B2B2B] border border-[#C8A96B]/60 text-white font-bold cursor-pointer shadow-md transition disabled:opacity-50"
            >
              {isSubmitting ? 'Saving to Database...' : 'Add Product to Store'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
