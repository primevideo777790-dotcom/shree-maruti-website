import React, { useState } from 'react';
import { Order, Product } from '../types';
import { useShop } from '../context/ShopContext';
import { 
  X, 
  RotateCcw, 
  Check, 
  Truck, 
  ShieldCheck, 
  Banknote, 
  CheckCircle2 
} from 'lucide-react';

interface ReturnModalProps {
  order: Order;
  product?: Product;
  onClose: () => void;
}

export const ReturnModal: React.FC<ReturnModalProps> = ({ order, product, onClose }) => {
  const { language, requestReturn } = useShop();

  const reasons = [
    { id: 'color_diff', textEn: 'Fabric color / shade looks different from image', textHi: 'कपड़े का रंग या शेड फोटो से अलग है' },
    { id: 'length_short', textEn: 'Fabric length is shorter than ordered', textHi: 'कपड़े की लंबाई ऑर्डर से कम है' },
    { id: 'quality_issue', textEn: 'Fabric quality/texture not as expected', textHi: 'कपड़े की क्वालिटी या अहसास पसंद नहीं आया' },
    { id: 'defect', textEn: 'Defective or damaged fabric piece', textHi: 'कपड़े में कट या दाग लगा हुआ है' },
    { id: 'changed_mind', textEn: 'Ordered by mistake / Changed my mind', textHi: 'गलती से ऑर्डर हो गया था / मन बदल गया' }
  ];

  const [selectedReason, setSelectedReason] = useState<string>(reasons[0].textEn);
  const [refundMethod, setRefundMethod] = useState<'bank_upi' | 'store_credit'>('bank_upi');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const prodId = product ? product.id : (order.items[0]?.product.id || 'unknown');
    requestReturn(order.id, prodId, selectedReason, refundMethod);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-md w-full p-6 text-center shadow-2xl border border-[#E5E0D8] animate-in zoom-in-95 duration-150">
          <div className="w-16 h-16 rounded-full bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center text-[#C8A96B] mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <h2 className="text-xl font-black text-[#111111]">
            {language === 'hi' ? 'वापसी (Return) बुक हो गई है!' : 'Return Pickup Scheduled!'}
          </h2>

          <p className="text-xs sm:text-sm text-[#4A4A4A] mt-2">
            {language === 'hi'
              ? 'हमारा कूरियर पार्टनर 24 से 48 घंटे में आपके घर आकर कपड़ा ले जाएगा। कपड़ा लेते ही आपके खाते में पैसे वापस भेज दिए जाएंगे।'
              : 'Our delivery agent will collect the fabric from your doorstep tomorrow. Refund will be processed upon pickup.'}
          </p>

          <div className="bg-[#F7F5F0] p-3 rounded-xl border border-[#E5E0D8] text-xs text-[#111111] my-4 text-left space-y-1">
            <div className="font-bold flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'पिकअप का पता:' : 'Pickup Address:'}</span>
            </div>
            <p className="text-[#4A4A4A]">{order.shippingAddress.houseFlat}, {order.shippingAddress.city}</p>
          </div>

          <button
            onClick={onClose}
            className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-3 px-4 rounded-xl text-sm transition cursor-pointer"
          >
            {language === 'hi' ? 'ठीक है, समझ गया' : 'Done & Close'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full my-auto overflow-hidden shadow-2xl border border-[#E5E0D8]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E5E0D8] bg-[#F7F5F0] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#111111] flex items-center justify-center text-[#C8A96B]">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#111111]">
                {language === 'hi' ? 'कपड़ा आसान वापसी (Easy Return)' : 'Easy Product Return'}
              </h2>
              <p className="text-xs text-[#777777]">
                Order #{order.orderNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white hover:bg-[#E5E0D8] text-[#111111] border border-[#E5E0D8] flex items-center justify-center transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5">
          {/* Reason Selection */}
          <div>
            <label className="block text-xs font-bold text-[#111111] uppercase tracking-wide mb-2">
              {language === 'hi' ? '1. कपड़ा वापस करने का कारण चुनें:' : '1. Select Return Reason:'}
            </label>
            <div className="space-y-2">
              {reasons.map((r) => {
                const isSelected = selectedReason === r.textEn;
                return (
                  <button
                    type="button"
                    key={r.id}
                    onClick={() => setSelectedReason(r.textEn)}
                    className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm font-semibold transition cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-[#111111] bg-[#F7F5F0] text-[#111111] ring-1 ring-[#111111]'
                        : 'border-[#E5E0D8] bg-white text-[#4A4A4A] hover:bg-[#F7F5F0]'
                    }`}
                  >
                    <span>{language === 'hi' ? r.textHi : r.textEn}</span>
                    {isSelected && <Check className="w-4 h-4 text-[#C8A96B] shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Refund Method */}
          <div>
            <label className="block text-xs font-bold text-[#111111] uppercase tracking-wide mb-2">
              {language === 'hi' ? '2. रिफंड के पैसे कैसे चाहिए?' : '2. Select Refund Method:'}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setRefundMethod('bank_upi')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                  refundMethod === 'bank_upi'
                    ? 'border-[#111111] bg-[#F7F5F0] text-[#111111] ring-1 ring-[#111111]'
                    : 'border-[#E5E0D8] bg-white text-[#4A4A4A] hover:bg-[#F7F5F0]'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-[#111111]">
                  <Banknote className="w-3.5 h-3.5 text-[#C8A96B]" />
                  <span>{language === 'hi' ? 'बैंक खाता / UPI में' : 'Bank Account / UPI'}</span>
                </div>
                <p className="text-[11px] text-[#777777] mt-1">
                  {language === 'hi' ? 'पिकअप के 24 घंटे में जमा' : 'Credited within 24 hrs'}
                </p>
              </button>

              <button
                type="button"
                onClick={() => setRefundMethod('store_credit')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition ${
                  refundMethod === 'store_credit'
                    ? 'border-[#111111] bg-[#F7F5F0] text-[#111111] ring-1 ring-[#111111]'
                    : 'border-[#E5E0D8] bg-white text-[#4A4A4A] hover:bg-[#F7F5F0]'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-[#111111]">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C8A96B]" />
                  <span>{language === 'hi' ? 'स्टोर क्रेडिट (तुरंत)' : 'Instant Store Credit'}</span>
                </div>
                <p className="text-[11px] text-[#777777] mt-1">
                  {language === 'hi' ? 'अगली खरीदारी में तुरंत छूट' : 'Usable on next order immediately'}
                </p>
              </button>
            </div>
          </div>

          {/* Doorstep Pickup Guarantee */}
          <div className="bg-[#F7F5F0] p-3 rounded-xl border border-[#E5E0D8] text-xs text-[#4A4A4A] flex items-center gap-2">
            <Truck className="w-4 h-4 text-[#C8A96B] shrink-0" />
            <span>
              {language === 'hi' 
                ? 'कूरियर डिलीवरी एजेंट आपके घर आकर कपड़ा पिकअप करेगा। आपको कहीं जाने की जरूरत नहीं है।' 
                : '100% Free Doorstep Pickup. You do not need to print any labels.'}
            </span>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <span>{language === 'hi' ? 'रिटर्न पिकअप कन्फर्म करें' : 'Confirm Return Pickup'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
