import React, { useEffect, useState } from 'react';
import { useShop } from '../context/ShopContext';
import { CategoryType } from '../types';
import { 
  Sparkles, 
  Flame, 
  Tag, 
  Crown, 
  Layers, 
  Grid,
  Shirt,
  Briefcase
} from 'lucide-react';

interface CategoryItem {
  key: CategoryType;
  labelEn: string;
  labelHi: string;
  icon: React.ReactNode;
}

export const CategoryBar: React.FC = () => {
  const [mobileOpen, setMobileOpen] = useState(true);

  useEffect(() => {
    const handler = () => setMobileOpen(v => !v);
    window.addEventListener('smk:toggle-filters', handler);
    return () => window.removeEventListener('smk:toggle-filters', handler);
  }, []);

  const { selectedCategory, setSelectedCategory, language, setSearchQuery, setActiveTab } = useShop();

  const categories: CategoryItem[] = [
    { key: 'all', labelEn: 'All Fabrics', labelHi: 'सभी कपड़े', icon: <Grid className="w-4 h-4" /> },
    { key: 'shirt', labelEn: 'Shirt Fabric', labelHi: 'शर्ट का कपड़ा', icon: <Shirt className="w-4 h-4" /> },
    { key: 'pant', labelEn: 'Pant Fabric', labelHi: 'पैंट का कपड़ा', icon: <Briefcase className="w-4 h-4" /> },
    { key: 'combo', labelEn: 'Shirt + Pant Combo', labelHi: 'शर्ट + पैंट जोड़ी', icon: <Layers className="w-4 h-4" /> },
    { key: 'premium', labelEn: 'Premium Suiting', labelHi: 'प्रीमियम फैब्रिक', icon: <Crown className="w-4 h-4" /> },
    { key: 'best_sellers', labelEn: 'Best Sellers', labelHi: 'सबसे ज्यादा बिकने वाले', icon: <Flame className="w-4 h-4 text-orange-600" /> },
    { key: 'new_arrivals', labelEn: 'New Arrivals', labelHi: 'नए डिजाइन', icon: <Sparkles className="w-4 h-4 text-amber-600" /> },
    { key: 'offers', labelEn: 'Special Offers', labelHi: 'खास छूट (Offers)', icon: <Tag className="w-4 h-4 text-red-600" /> },
  ];

  const handleCategorySelect = (catKey: CategoryType) => {
    setSelectedCategory(catKey);
    setSearchQuery('');
    setActiveTab('home');
  };

  return (
    <div className="hidden sm:block bg-white border-b border-[#E5E0D8] sticky top-[73px] z-30 shadow-sm backdrop-blur-sm">
      <div className={`${mobileOpen ? 'flex' : 'hidden'} sm:flex max-w-7xl mx-auto px-4 py-3 overflow-x-auto scrollbar-none items-center gap-2 sm:gap-2.5`}>
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => handleCategorySelect(cat.key)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-150 cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-[#111111] text-white shadow-xs ring-1 ring-[#111111]'
                  : 'bg-white text-[#4A4A4A] hover:text-[#111111] hover:border-[#C8A96B] border border-[#E5E0D8]'
              }`}
            >
              <span className={isActive ? 'text-[#C8A96B]' : 'text-[#777777]'}>
                {cat.icon}
              </span>
              <span>{language === 'hi' ? cat.labelHi : cat.labelEn}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
