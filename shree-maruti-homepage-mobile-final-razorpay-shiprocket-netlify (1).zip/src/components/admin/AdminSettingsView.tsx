import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { changeAdminPassword } from '../../utils/adminAuth';
import { 
  DEFAULT_VIDEO_PRESETS, 
  loadVideoPresets, 
  VideoPresetItem 
} from '../ThreeDVideoPlayer';
import { 
  KeyRound, 
  ShieldCheck, 
  Building, 
  CheckCircle2, 
  AlertCircle, 
  Truck, 
  MapPin, 
  Phone, 
  Mail,
  Tv,
  Sparkles,
  RotateCw,
  Video,
  FileCode,
  ExternalLink,
  Save,
  RotateCcw,
  CreditCard,
  QrCode,
  Server,
  Loader2,
  Zap,
  Check
} from 'lucide-react';

export const AdminSettingsView: React.FC = () => {
  const { adminSession, storeSettings, updateStoreSettings } = useShop();

  const [currentUsername] = useState(adminSession?.username || 'admin');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [loading, setLoading] = useState(false);

  // PhonePe Gateway State (with instant cached load & backend sync)
  const [phonepeMerchantId, setPhonepeMerchantId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('smk_phonepe_config');
      return saved ? JSON.parse(saved).merchantId || 'PGTESTPAYUAT' : 'PGTESTPAYUAT';
    } catch {
      return 'PGTESTPAYUAT';
    }
  });
  const [phonepeSaltKey, setPhonepeSaltKey] = useState('');
  const [phonepeSaltIndex, setPhonepeSaltIndex] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('smk_phonepe_config');
      return saved ? String(JSON.parse(saved).saltIndex || '1') : '1';
    } catch {
      return '1';
    }
  });
  const [phonepeEnv, setPhonepeEnv] = useState<'sandbox' | 'production'>(() => {
    try {
      const saved = localStorage.getItem('smk_phonepe_config');
      return saved ? (JSON.parse(saved).environment || 'sandbox') : 'sandbox';
    } catch {
      return 'sandbox';
    }
  });
  const [phonepeUpi, setPhonepeUpi] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('smk_phonepe_config');
      return saved ? JSON.parse(saved).phonepeUpi || 'shreemarutikrupa@ybl' : 'shreemarutikrupa@ybl';
    } catch {
      return 'shreemarutikrupa@ybl';
    }
  });
  const [phonepeLoading, setPhonepeLoading] = useState(false);
  const [phonepeTesting, setPhonepeTesting] = useState(false);
  const [phonepeMsg, setPhonepeMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [phonepeTestResult, setPhonepeTestResult] = useState<string | null>(null);

  // Load PhonePe Gateway Config from Backend
  const loadPhonePeConfig = () => {
    fetch('/api/payment/phonepe/config')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.config) {
          setPhonepeMerchantId(data.config.merchantId || 'PGTESTPAYUAT');
          setPhonepeSaltIndex(String(data.config.saltIndex || '1'));
          setPhonepeEnv(data.config.environment || 'sandbox');
          setPhonepeUpi(data.config.phonepeUpi || 'shreemarutikrupa@ybl');
          try {
            localStorage.setItem('smk_phonepe_config', JSON.stringify(data.config));
          } catch {}
        }
      })
      .catch(() => {});
  };

  React.useEffect(() => {
    loadPhonePeConfig();
  }, []);

  const handleSavePhonePeSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhonepeLoading(true);
    setPhonepeMsg(null);
    try {
      const res = await fetch('/api/payment/phonepe/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchantId: phonepeMerchantId,
          saltKey: phonepeSaltKey,
          saltIndex: phonepeSaltIndex,
          environment: phonepeEnv,
          phonepeUpi: phonepeUpi,
          enabled: true,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setPhonepeMsg({ type: 'success', text: 'PhonePe Gateway settings saved successfully to backend!' });
        setPhonepeSaltKey(''); // Clear secret input after saving
        if (data.config) {
          try {
            localStorage.setItem('smk_phonepe_config', JSON.stringify(data.config));
          } catch {}
        }
        loadPhonePeConfig();
      } else {
        setPhonepeMsg({ type: 'error', text: data.error || 'Failed to save settings' });
      }
    } catch {
      setPhonepeMsg({ type: 'error', text: 'Error connecting to server' });
    } finally {
      setPhonepeLoading(false);
    }
  };

  const handleTestPhonePeConnection = async () => {
    setPhonepeTesting(true);
    setPhonepeTestResult(null);
    try {
      const res = await fetch('/api/payment/phonepe/test-connection', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setPhonepeTestResult(`✓ ${data.message}`);
      } else {
        setPhonepeTestResult('✗ Connection failed: ' + (data.error || 'Check credentials'));
      }
    } catch {
      setPhonepeTestResult('✗ Network error during connection test');
    } finally {
      setPhonepeTesting(false);
    }
  };

  // 3D Video Editor State
  const [videoPresets, setVideoPresets] = useState<VideoPresetItem[]>(loadVideoPresets);
  const [selectedPresetIndex, setSelectedPresetIndex] = useState(0);
  const [videoSaveMsg, setVideoSaveMsg] = useState<string | null>(null);
  const [videoSaving, setVideoSaving] = useState(false);

  // Fetch 3D video settings from backend on mount
  React.useEffect(() => {
    fetch('/api/settings/3d-video')
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.presets) && data.presets.length > 0) {
          setVideoPresets(data.presets);
          try {
            localStorage.setItem('smk_3d_video_config', JSON.stringify(data.presets));
          } catch {}
        }
      })
      .catch(() => {});
  }, []);

  const activeVideo = videoPresets[selectedPresetIndex] || videoPresets[0];

  const handleUpdateActiveVideo = (field: keyof VideoPresetItem, value: string) => {
    setVideoPresets(prev => {
      const copy = [...prev];
      copy[selectedPresetIndex] = {
        ...copy[selectedPresetIndex],
        [field]: value
      };
      return copy;
    });
  };

  const handleSaveVideoSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setVideoSaving(true);
    setVideoSaveMsg(null);
    try {
      const res = await fetch('/api/settings/3d-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ presets: videoPresets })
      });
      const data = await res.json();
      if (data.success) {
        try {
          localStorage.setItem('smk_3d_video_config', JSON.stringify(videoPresets));
        } catch {}
        window.dispatchEvent(new Event('smk_3d_video_updated'));
        setVideoSaveMsg('3D Video settings saved successfully to backend database & updated live on home page!');
        setTimeout(() => setVideoSaveMsg(null), 5000);
      } else {
        setVideoSaveMsg('Failed to save settings: ' + (data.error || 'Server error'));
      }
    } catch {
      setVideoSaveMsg('Error connecting to server.');
    } finally {
      setVideoSaving(false);
    }
  };

  const handleResetVideoDefaults = async () => {
    if (window.confirm('Reset all 3D video settings to factory defaults?')) {
      try {
        const res = await fetch('/api/settings/3d-video/reset', { method: 'POST' });
        const data = await res.json();
        if (data.success && data.presets) {
          setVideoPresets(data.presets);
          setSelectedPresetIndex(0);
          try {
            localStorage.removeItem('smk_3d_video_config');
          } catch {}
          window.dispatchEvent(new Event('smk_3d_video_updated'));
          setVideoSaveMsg('3D Video reset to default videos successfully.');
          setTimeout(() => setVideoSaveMsg(null), 3000);
        }
      } catch {
        setVideoPresets(DEFAULT_VIDEO_PRESETS);
        setSelectedPresetIndex(0);
        window.dispatchEvent(new Event('smk_3d_video_updated'));
      }
    }
  };

  // Store Business Profile State
  const [storeProfile, setStoreProfile] = useState(storeSettings);
  const [isEditingStore, setIsEditingStore] = useState(false);
  const [storeSaving, setStoreSaving] = useState(false);
  const [storeMsg, setStoreMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Sync with storeSettings whenever loaded or updated unless actively editing
  React.useEffect(() => {
    if (!isEditingStore) {
      setStoreProfile(storeSettings);
    }
  }, [storeSettings, isEditingStore]);

  const handleSaveStoreProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setStoreSaving(true);
    setStoreMsg(null);
    try {
      const ok = await updateStoreSettings(storeProfile);
      if (ok) {
        setStoreMsg({ type: 'success', text: 'Merchant profile and warehouse details saved successfully to backend database!' });
        setIsEditingStore(false);
        setTimeout(() => setStoreMsg(null), 4000);
      } else {
        setStoreMsg({ type: 'error', text: 'Failed to save store profile to database' });
      }
    } catch {
      setStoreMsg({ type: 'error', text: 'Error connecting to server' });
    } finally {
      setStoreSaving(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);

    if (newPassword.length < 6) {
      setMsg({ type: 'error', text: 'New password must be at least 6 characters long.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setMsg({ type: 'error', text: 'Passwords do not match. Please re-enter.' });
      return;
    }

    setLoading(true);
    try {
      const ok = await changeAdminPassword(currentUsername, newPassword);
      if (ok) {
        setMsg({ type: 'success', text: 'Admin password updated successfully! Use your new password on next login.' });
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setMsg({ type: 'error', text: 'Failed to change password. Please try again.' });
      }
    } catch {
      setMsg({ type: 'error', text: 'An unexpected error occurred.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="pb-3 border-b border-[#2B2B2B]">
        <h1 className="text-xl sm:text-2xl font-black text-white font-serif">
          Store & 3D Video Settings
        </h1>
        <p className="text-xs text-[#D9D4CA]/70 mt-0.5">
          Manage 3D home page videos, fabrics, credentials, and Surat warehouse dispatch rules
        </p>
      </div>

      {/* 3D Video & Studio Manager Section */}
      <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl p-5 sm:p-6 shadow-md space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#2B2B2B]">
          <div className="flex items-center gap-2.5 text-white">
            <div className="w-8 h-8 rounded-lg bg-[#C8A96B]/20 border border-[#C8A96B]/40 flex items-center justify-center text-[#C8A96B]">
              <Tv className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-white">
                3D Live Video & Showcase Manager (होम पेज 3D वीडियो सेटिंग)
              </h2>
              <p className="text-xs text-[#777777]">
                Change video URL, titles, poster image, and tags shown on the home page
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleResetVideoDefaults}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1E1E1E] hover:bg-[#2B2B2B] text-[#D9D4CA] border border-[#2B2B2B] rounded-xl text-xs font-semibold cursor-pointer transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>
        </div>

        {videoSaveMsg && (
          <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{videoSaveMsg}</span>
          </div>
        )}

        {/* Preset Selector Tabs */}
        <div>
          <span className="text-xs font-bold text-[#D9D4CA] uppercase tracking-wide block mb-2">
            Select 3D Video Slot to Edit:
          </span>
          <div className="flex flex-wrap gap-2">
            {videoPresets.map((preset, index) => (
              <button
                key={preset.id}
                type="button"
                onClick={() => setSelectedPresetIndex(index)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer border ${
                  selectedPresetIndex === index
                    ? 'bg-[#C8A96B] text-[#111111] border-[#C8A96B] shadow-sm'
                    : 'bg-[#1E1E1E] text-[#D9D4CA] border-[#2B2B2B] hover:border-[#C8A96B]/40'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                <span>Slot {index + 1}: {preset.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Video Edit Form */}
        <form onSubmit={handleSaveVideoSettings} className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* Video URL */}
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">
              Direct Video MP4 / WebM URL (सीधा वीडियो लिंक):
            </label>
            <input
              type="url"
              required
              value={activeVideo.videoUrl}
              onChange={(e) => handleUpdateActiveVideo('videoUrl', e.target.value)}
              placeholder="https://example.com/fabric-drape.mp4"
              className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white text-xs font-mono focus:outline-none focus:border-[#C8A96B]"
            />
            <span className="text-[11px] text-[#777777] mt-0.5 block">
              Tip: Supports public direct .mp4 or .webm links (Google Cloud, Cloudinary, AWS S3, etc.)
            </span>
          </div>

          {/* Poster Image URL */}
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">
              Poster Cover Image URL (पोस्टर फोटो):
            </label>
            <input
              type="url"
              required
              value={activeVideo.posterUrl}
              onChange={(e) => handleUpdateActiveVideo('posterUrl', e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white text-xs font-mono focus:outline-none focus:border-[#C8A96B]"
            />
          </div>

          {/* English Title */}
          <div>
            <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">
              English Title:
            </label>
            <input
              type="text"
              required
              value={activeVideo.title}
              onChange={(e) => handleUpdateActiveVideo('title', e.target.value)}
              placeholder="3D Luxury Fabric Flow & Drape"
              className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white text-xs focus:outline-none focus:border-[#C8A96B]"
            />
          </div>

          {/* Hindi Title */}
          <div>
            <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">
              Hindi Title (हिंदी नाम):
            </label>
            <input
              type="text"
              required
              value={activeVideo.titleHi}
              onChange={(e) => handleUpdateActiveVideo('titleHi', e.target.value)}
              placeholder="3D रॉयल फैब्रिक ड्रेप व फ्लो"
              className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white text-xs focus:outline-none focus:border-[#C8A96B]"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">
              Description / Fabric Details:
            </label>
            <input
              type="text"
              required
              value={activeVideo.desc}
              onChange={(e) => handleUpdateActiveVideo('desc', e.target.value)}
              placeholder="Pure Giza cotton & gold thread sheen in motion"
              className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white text-xs focus:outline-none focus:border-[#C8A96B]"
            />
          </div>

          {/* Tag Badge */}
          <div>
            <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">
              Badge Tag (बैज नाम):
            </label>
            <input
              type="text"
              required
              value={activeVideo.tag}
              onChange={(e) => handleUpdateActiveVideo('tag', e.target.value)}
              placeholder="RAYMOND SPECIAL"
              className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white text-xs focus:outline-none focus:border-[#C8A96B]"
            />
          </div>

          {/* Save Button */}
          <div className="md:col-span-2 pt-2">
            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 bg-[#C8A96B] hover:bg-[#b8985a] text-[#111111] font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-md active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Save & Publish 3D Video to Home Page</span>
            </button>
          </div>
        </form>

        {/* Code Files Reference Helper */}
        <div className="bg-[#151515] border border-[#2B2B2B] rounded-xl p-4 text-xs text-[#D9D4CA] space-y-2 mt-4">
          <div className="flex items-center gap-2 text-[#C8A96B] font-bold">
            <FileCode className="w-4 h-4" />
            <span>Developer Code Reference (कोड में कहाँ से एडिट करें):</span>
          </div>
          <p className="text-[11px] text-[#777777]">
            अगर आप कोड फाइल से सीधे 3D एनिमेशन, Three.js वेव स्पीड, या कलर शेड बदलना चाहते हैं, तो निम्नलिखित फाइल्स में बदलाव कर सकते हैं:
          </p>
          <ul className="list-disc pl-4 space-y-1 font-mono text-[11px] text-[#D9D4CA]">
            <li>
              <strong className="text-white">src/components/ThreeDVideoPlayer.tsx</strong> — 3D वीडियो प्लेयर, Three.js 360° फैब्रिक सिमुलेशन और वीडियो लिस्ट।
            </li>
            <li>
              <strong className="text-white">src/components/ThreeDShowcaseSection.tsx</strong> — होम पेज पर बना पूरा 3D लाइव फैब्रिक शोकेस सेक्शन।
            </li>
            <li>
              <strong className="text-white">src/components/Banner.tsx</strong> — होम पेज का मुख्य हीरो बैनर जिसमें 3D वीडियो लोड होता है।
            </li>
          </ul>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Security / Password Management */}
        <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-white">
            <KeyRound className="w-5 h-5 text-[#C8A96B]" />
            <h2 className="text-sm font-bold uppercase tracking-wider">Change Admin Password</h2>
          </div>

          {msg && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
              msg.type === 'success' 
                ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300' 
                : 'bg-rose-950/60 border border-rose-500/40 text-rose-300'
            }`}>
              {msg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{msg.text}</span>
            </div>
          )}

          <form onSubmit={handlePasswordChange} className="space-y-3 text-xs">
            <div>
              <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">Current Username</label>
              <input
                type="text"
                disabled
                value={currentUsername}
                className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-[#777777] cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">New Secure Password</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter at least 6 characters"
                className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D9D4CA] mb-1">Confirm New Password</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-type new password"
                className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 bg-[#111111] hover:bg-[#2B2B2B] text-white border border-[#2B2B2B] font-bold py-2.5 rounded-xl text-xs transition cursor-pointer shadow-md disabled:opacity-50"
            >
              {loading ? 'Updating Password...' : 'Save New Admin Password'}
            </button>
          </form>
        </div>

        {/* Store Business Profile */}
        <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-2">
              <Building className="w-5 h-5 text-[#C8A96B]" />
              <h2 className="text-sm font-bold uppercase tracking-wider">Merchant Profile & GSTIN</h2>
            </div>
            <button
              type="button"
              onClick={() => setIsEditingStore(!isEditingStore)}
              className="text-xs text-[#C8A96B] hover:underline font-bold cursor-pointer"
            >
              {isEditingStore ? 'Cancel' : 'Edit Profile'}
            </button>
          </div>

          {storeMsg && (
            <div className={`p-2.5 rounded-xl text-xs flex items-center gap-2 ${
              storeMsg.type === 'success' 
                ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300' 
                : 'bg-rose-950/60 border border-rose-500/40 text-rose-300'
            }`}>
              {storeMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{storeMsg.text}</span>
            </div>
          )}

          {isEditingStore ? (
            <form onSubmit={handleSaveStoreProfile} className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] text-stone-400 mb-1">Trade Name</label>
                <input
                  type="text"
                  value={storeProfile.tradeName}
                  onChange={(e) => setStoreProfile({ ...storeProfile, tradeName: e.target.value })}
                  className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-stone-400 mb-1">GSTIN</label>
                <input
                  type="text"
                  value={storeProfile.gstin}
                  onChange={(e) => setStoreProfile({ ...storeProfile, gstin: e.target.value })}
                  className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white font-mono focus:outline-none focus:border-[#C8A96B]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-stone-400 mb-1">Warehouse Address</label>
                <input
                  type="text"
                  value={storeProfile.warehouseAddress}
                  onChange={(e) => setStoreProfile({ ...storeProfile, warehouseAddress: e.target.value })}
                  className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-stone-400 mb-1">Phone</label>
                  <input
                    type="text"
                    value={storeProfile.phone}
                    onChange={(e) => setStoreProfile({ ...storeProfile, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-stone-400 mb-1">Email</label>
                  <input
                    type="email"
                    value={storeProfile.email}
                    onChange={(e) => setStoreProfile({ ...storeProfile, email: e.target.value })}
                    className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] text-stone-400 mb-1">Default Courier</label>
                <input
                  type="text"
                  value={storeProfile.defaultCourier}
                  onChange={(e) => setStoreProfile({ ...storeProfile, defaultCourier: e.target.value })}
                  className="w-full px-3 py-2 bg-[#151515] border border-[#2B2B2B] rounded-xl text-white focus:outline-none focus:border-[#C8A96B]"
                />
              </div>
              <button
                type="submit"
                disabled={storeSaving}
                className="w-full py-2 bg-[#C8A96B] hover:bg-[#b8985a] text-[#111111] font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {storeSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                <span>Save Merchant Profile</span>
              </button>
            </form>
          ) : (
            <div className="space-y-3 text-xs text-[#D9D4CA]">
              <div className="bg-[#151515] p-3 rounded-xl border border-[#2B2B2B] space-y-1">
                <span className="text-[10px] text-[#777777] uppercase font-bold block">Trade Name</span>
                <p className="font-bold text-white text-sm font-serif">{storeProfile.tradeName}</p>
                <p className="text-[11px] text-[#C8A96B] font-mono">GSTIN: {storeProfile.gstin}</p>
              </div>

              <div className="bg-[#151515] p-3 rounded-xl border border-[#2B2B2B] space-y-1">
                <span className="text-[10px] text-[#777777] uppercase font-bold block">Surat Central Warehouse</span>
                <p className="flex items-start gap-1.5 text-[#D9D4CA]">
                  <MapPin className="w-3.5 h-3.5 text-[#C8A96B] shrink-0 mt-0.5" />
                  <span>{storeProfile.warehouseAddress}</span>
                </p>
              </div>

              <div className="bg-[#151515] p-3 rounded-xl border border-[#2B2B2B] space-y-1">
                <span className="text-[10px] text-[#777777] uppercase font-bold block">Contact Channels</span>
                <p className="flex items-center gap-1.5 text-[#D9D4CA]">
                  <Phone className="w-3.5 h-3.5 text-[#C8A96B] shrink-0" />
                  <span>{storeProfile.phone}</span>
                </p>
                <p className="flex items-center gap-1.5 text-[#D9D4CA]">
                  <Mail className="w-3.5 h-3.5 text-[#C8A96B] shrink-0" />
                  <span>{storeProfile.email}</span>
                </p>
              </div>

              <div className="bg-[#151515] p-3 rounded-xl border border-[#2B2B2B]">
                <span className="text-[10px] text-[#777777] uppercase font-bold block mb-1">Logistics Integrations</span>
                <p className="text-[#D9D4CA]/80 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-[#C8A96B]" />
                  <span>Default Courier: <strong>{storeProfile.defaultCourier}</strong></span>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Payment Backend & PhonePe Gateway */}
      <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl p-5 sm:p-6 shadow-sm space-y-5">
        {/* Payment Backend Status */}
        <div className="bg-[#151515] p-3.5 rounded-xl border border-[#C8A96B]/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-[#C8A96B]" />
                  <span>पेमेंट बैकएंड API (Full-Stack Backend)</span>
                </span>
                <span className="bg-emerald-950 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/30">
                  LIVE & ACTIVE
                </span>
              </div>
              <div className="text-[11px] text-[#D9D4CA]/90 space-y-1 bg-[#101010] p-2.5 rounded-lg border border-[#222222]">
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">Server Backend:</span>
                  <span className="font-mono text-emerald-400 font-bold">Express Node.js (:3000)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">UPI Gateway VPA:</span>
                  <span className="font-mono text-[#C8A96B] font-bold">shreemarutikrupa@okaxis</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">Dynamic QR Engine:</span>
                  <span className="text-white">Active (0% Transaction Fee)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">Cash on Delivery:</span>
                  <span className="text-white">Enabled across India (Zero Advance)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">Persistent Storage:</span>
                  <span className="font-mono text-stone-300">data/orders.json & data/payments.json</span>
                </div>
              </div>
            </div>

            {/* PhonePe Gateway Configuration Form */}
            <div className="bg-[#151515] p-4 rounded-xl border border-purple-500/40 space-y-3">
              <div className="flex items-center justify-between border-b border-[#252525] pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-[#5f259f] flex items-center justify-center text-white text-[11px] font-black">
                    पे
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">PhonePe Payment Gateway Setup</h4>
                    <p className="text-[10px] text-stone-400">PhonePe Business PG credentials & UPI settings</p>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                  phonepeEnv === 'production' 
                    ? 'bg-emerald-950 text-emerald-400 border-emerald-500/30' 
                    : 'bg-purple-950 text-purple-300 border-purple-500/30'
                }`}>
                  {phonepeEnv.toUpperCase()}
                </span>
              </div>

              {phonepeMsg && (
                <div className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                  phonepeMsg.type === 'success' 
                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30' 
                    : 'bg-red-950/60 text-red-300 border border-red-500/30'
                }`}>
                  {phonepeMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                  <span>{phonepeMsg.text}</span>
                </div>
              )}

              {phonepeTestResult && (
                <div className={`p-2 rounded-lg text-[11px] font-mono ${
                  phonepeTestResult.startsWith('✓') 
                    ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/20' 
                    : 'bg-red-950/40 text-red-300 border border-red-500/20'
                }`}>
                  {phonepeTestResult}
                </div>
              )}

              <form onSubmit={handleSavePhonePeSettings} className="space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">Environment / Mode</label>
                    <select
                      value={phonepeEnv}
                      onChange={(e) => setPhonepeEnv(e.target.value as 'sandbox' | 'production')}
                      className="w-full bg-[#101010] border border-[#2B2B2B] text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-purple-500"
                    >
                      <option value="sandbox">Sandbox (Testing / UAT)</option>
                      <option value="production">Production (Live Payments)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">PhonePe Merchant ID</label>
                    <input
                      type="text"
                      value={phonepeMerchantId}
                      onChange={(e) => setPhonepeMerchantId(e.target.value)}
                      placeholder="e.g. PGTESTPAYUAT or M230616..."
                      className="w-full bg-[#101010] border border-[#2B2B2B] text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-purple-500 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-[11px] text-stone-400 block mb-1">
                      Salt Key (Secret)
                      <span className="text-[10px] text-stone-500 ml-1">(Leave blank to keep current)</span>
                    </label>
                    <input
                      type="password"
                      value={phonepeSaltKey}
                      onChange={(e) => setPhonepeSaltKey(e.target.value)}
                      placeholder="Enter Salt Key / Secret"
                      className="w-full bg-[#101010] border border-[#2B2B2B] text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-purple-500 font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">Salt Index</label>
                    <input
                      type="text"
                      value={phonepeSaltIndex}
                      onChange={(e) => setPhonepeSaltIndex(e.target.value)}
                      placeholder="e.g. 1"
                      className="w-full bg-[#101010] border border-[#2B2B2B] text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-purple-500 font-mono text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-stone-400 block mb-1">
                    PhonePe Merchant UPI ID (for instant direct zero-fee settlement)
                  </label>
                  <input
                    type="text"
                    value={phonepeUpi}
                    onChange={(e) => setPhonepeUpi(e.target.value)}
                    placeholder="e.g. shreemarutikrupa@ybl or yournumber@ybl"
                    className="w-full bg-[#101010] border border-[#2B2B2B] text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-purple-500 font-mono text-xs"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    disabled={phonepeTesting}
                    onClick={handleTestPhonePeConnection}
                    className="px-3 py-2 bg-[#202020] hover:bg-[#2b2b2b] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {phonepeTesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5 text-amber-400" />}
                    <span>Test Gateway</span>
                  </button>

                  <button
                    type="submit"
                    disabled={phonepeLoading}
                    className="flex-1 px-4 py-2 bg-[#5f259f] hover:bg-[#4d1d82] text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50 transition"
                  >
                    {phonepeLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                    <span>Save PhonePe Settings</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      );
    };
