import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { ReturnRequest } from '../../types';
import { 
  RotateCcw, 
  Search, 
  CheckCircle2, 
  Clock, 
  Truck, 
  Banknote, 
  ShieldCheck, 
  XCircle, 
  Phone, 
  AlertCircle 
} from 'lucide-react';

export const AdminReturnsView: React.FC = () => {
  const { returnRequests, updateReturnStatus } = useShop();

  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [updatingReturnId, setUpdatingReturnId] = useState<string | null>(null);

  const handleUpdateReturn = async (id: string, status: 'approved' | 'picked_up' | 'refunded' | 'rejected') => {
    setUpdatingReturnId(id);
    try {
      await updateReturnStatus(id, status);
    } finally {
      setUpdatingReturnId(null);
    }
  };

  const filtered = returnRequests.filter(r => {
    if (filter !== 'all' && r.status !== filter) return false;
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      return (
        r.orderNumber.toLowerCase().includes(q) ||
        r.customerName.toLowerCase().includes(q) ||
        r.customerPhone.includes(q) ||
        r.productName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-stone-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-serif">
            Return Requests & Refunds
          </h1>
          <p className="text-xs text-stone-400 mt-0.5">
            Customer doorstep returns and 24-hr refund settlements
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by order or customer..."
            className="w-full pl-9 pr-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'All Requests', count: returnRequests.length },
          { id: 'pending', label: 'Pending Review', count: returnRequests.filter(r => r.status === 'pending').length },
          { id: 'approved', label: 'Pickup Approved', count: returnRequests.filter(r => r.status === 'approved').length },
          { id: 'picked_up', label: 'Picked Up', count: returnRequests.filter(r => r.status === 'picked_up').length },
          { id: 'refunded', label: 'Refund Completed', count: returnRequests.filter(r => r.status === 'refunded').length },
          { id: 'rejected', label: 'Rejected', count: returnRequests.filter(r => r.status === 'rejected').length }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              filter === tab.id
                ? 'bg-amber-800 text-white shadow-xs'
                : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
            }`}
          >
            <span>{tab.label}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              filter === tab.id ? 'bg-amber-950 text-amber-200' : 'bg-stone-800 text-stone-500'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Return Requests List */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-sm">
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-stone-400 text-xs">
            <RotateCcw className="w-10 h-10 text-stone-600 mx-auto mb-2" />
            <p className="font-bold text-stone-300">No return requests found</p>
            <p className="text-[11px] text-stone-500 mt-1">All customers are satisfied or no returns match this filter.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-950 text-stone-400 text-[11px] uppercase tracking-wider border-b border-stone-800">
                <tr>
                  <th className="py-3 px-4">Order & Date</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Fabric Product</th>
                  <th className="py-3 px-4">Reason & Refund Mode</th>
                  <th className="py-3 px-4">Return Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/80 text-stone-300">
                {filtered.map(r => (
                  <tr key={r.id} className="hover:bg-stone-850/60 transition">
                    <td className="py-3.5 px-4 font-mono">
                      <span className="font-bold text-amber-400 block text-xs">#{r.orderNumber}</span>
                      <span className="text-[11px] text-stone-400 mt-0.5 block">{r.requestDate}</span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-bold text-white block">{r.customerName}</span>
                      <span className="text-[11px] text-stone-400 font-mono flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-stone-500" />
                        +91 {r.customerPhone}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-medium text-stone-200 block truncate max-w-[200px]">
                        {r.productName}
                      </span>
                      {r.variantColor && (
                        <span className="text-[11px] text-stone-400">Color: {r.variantColor}</span>
                      )}
                      <span className="text-amber-300 font-bold block text-xs mt-0.5">₹{r.amount}</span>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="text-stone-300 italic max-w-[220px]">
                        "{r.reason}"
                      </p>
                      <span className="inline-block mt-1 text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-stone-800 text-stone-400">
                        {r.refundMethod === 'bank_upi' ? 'Bank Account / UPI' : 'Store Credit'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`inline-block px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
                        r.status === 'refunded'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : r.status === 'picked_up'
                          ? 'bg-blue-950 text-blue-300 border border-blue-800'
                          : r.status === 'approved'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                          : r.status === 'rejected'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {r.status.replace(/_/g, ' ')}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {r.status === 'pending' && (
                          <>
                            <button
                              disabled={updatingReturnId === r.id}
                              onClick={() => handleUpdateReturn(r.id, 'approved')}
                              className="bg-cyan-800 hover:bg-cyan-700 disabled:opacity-50 text-white font-bold px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer"
                            >
                              {updatingReturnId === r.id ? 'Saving...' : '✓ Approve Pickup'}
                            </button>
                            <button
                              disabled={updatingReturnId === r.id}
                              onClick={() => handleUpdateReturn(r.id, 'rejected')}
                              className="bg-stone-800 hover:bg-red-950 hover:text-red-400 disabled:opacity-50 text-stone-400 font-bold px-2 py-1 rounded-lg text-[11px] transition cursor-pointer"
                            >
                              Reject
                            </button>
                          </>
                        )}

                        {r.status === 'approved' && (
                          <button
                            disabled={updatingReturnId === r.id}
                            onClick={() => handleUpdateReturn(r.id, 'picked_up')}
                            className="bg-blue-800 hover:bg-blue-700 disabled:opacity-50 text-white font-bold px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer"
                          >
                            {updatingReturnId === r.id ? 'Saving...' : '📦 Mark Picked Up'}
                          </button>
                        )}

                        {r.status === 'picked_up' && (
                          <button
                            disabled={updatingReturnId === r.id}
                            onClick={() => handleUpdateReturn(r.id, 'refunded')}
                            className="bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold px-2.5 py-1 rounded-lg text-[11px] transition cursor-pointer shadow-sm"
                          >
                            {updatingReturnId === r.id ? 'Processing...' : `Process Refund (₹${r.amount})`}
                          </button>
                        )}

                        {r.status === 'refunded' && (
                          <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1 justify-end">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Refund Settled
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
