const SHIPROCKET_BASE_URL = 'https://apiv2.shiprocket.in/v1/external';

let cachedToken = null;
let cachedTokenExpiresAt = 0;

async function getShiprocketToken() {
  const email = String(process.env.SHIPROCKET_EMAIL || '').trim();
  const password = String(process.env.SHIPROCKET_PASSWORD || '').trim();

  if (!email || !password) {
    throw new Error('Shiprocket credentials are not configured on Netlify.');
  }

  if (cachedToken && cachedTokenExpiresAt > Date.now() + 5 * 60 * 1000) {
    return cachedToken;
  }

  const response = await fetch(`${SHIPROCKET_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  const json = await response.json().catch(() => ({}));
  if (!response.ok || !json?.token) {
    const message = json?.message || json?.error || `Authentication failed (${response.status})`;
    throw new Error(`Shiprocket authentication failed: ${message}`);
  }

  cachedToken = String(json.token);
  // Shiprocket documents a 240-hour token lifetime; refresh early.
  cachedTokenExpiresAt = Date.now() + 9 * 24 * 60 * 60 * 1000;
  return cachedToken;
}

async function shiprocketRequest(pathname, init = {}) {
  let token = await getShiprocketToken();
  const headers = new Headers(init.headers || {});
  headers.set('Content-Type', 'application/json');
  headers.set('Authorization', `Bearer ${token}`);

  let response = await fetch(`${SHIPROCKET_BASE_URL}${pathname}`, { ...init, headers });
  let json = await response.json().catch(() => ({}));

  if (response.status === 401) {
    cachedToken = null;
    cachedTokenExpiresAt = 0;
    token = await getShiprocketToken();
    headers.set('Authorization', `Bearer ${token}`);
    response = await fetch(`${SHIPROCKET_BASE_URL}${pathname}`, { ...init, headers });
    json = await response.json().catch(() => ({}));
  }

  if (!response.ok) {
    const message = json?.message || json?.error || json?.errors || `Shiprocket API error (${response.status})`;
    throw new Error(typeof message === 'string' ? message : JSON.stringify(message));
  }

  return json;
}

function splitName(fullName) {
  const parts = String(fullName || 'Customer').trim().split(/\s+/).filter(Boolean);
  return {
    first: parts[0] || 'Customer',
    last: parts.slice(1).join(' ') || '',
  };
}

function shiprocketOrderDate(order) {
  const candidate = order?.createdAt || order?.date;
  const parsed = candidate ? new Date(candidate) : new Date();
  const safe = Number.isNaN(parsed.getTime()) ? new Date() : parsed;
  const pad = (n) => String(n).padStart(2, '0');
  return `${safe.getFullYear()}-${pad(safe.getMonth() + 1)}-${pad(safe.getDate())} ${pad(safe.getHours())}:${pad(safe.getMinutes())}`;
}

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function getOrderFromBody(body) {
  if (!body || typeof body !== 'object' || !body.order || typeof body.order !== 'object') {
    return null;
  }
  return body.order;
}

export default async function handler(request) {
  const url = new URL(request.url);
  const pathname = url.pathname;

  // GET /api/shiprocket/config
  if (request.method === 'GET' && pathname.endsWith('/config')) {
    return jsonResponse({
      success: true,
      configured: Boolean(process.env.SHIPROCKET_EMAIL && process.env.SHIPROCKET_PASSWORD),
      pickupLocationConfigured: Boolean(process.env.SHIPROCKET_PICKUP_LOCATION),
    });
  }

  // POST /api/shiprocket/orders/:id/create
  if (request.method === 'POST' && pathname.includes('/orders/') && pathname.endsWith('/create')) {
    try {
      const body = await request.json().catch(() => ({}));
      const order = getOrderFromBody(body);

      if (!order) {
        return jsonResponse({ success: false, error: 'Order data is required.' }, 400);
      }

      if (order.shiprocketOrderId && order.shiprocketShipmentId) {
        return jsonResponse({
          success: true,
          alreadyCreated: true,
          order,
          shiprocket: {
            orderId: order.shiprocketOrderId,
            shipmentId: order.shiprocketShipmentId,
            awbCode: order.shiprocketAwbCode || '',
            courierName: order.shiprocketCourierName || '',
          },
        });
      }

      if (order.paymentMethod !== 'cod' && order.paymentStatus !== 'paid') {
        return jsonResponse({
          success: false,
          error: 'Prepaid order is not payment-confirmed yet. Mark the payment as Paid before creating the Shiprocket shipment.',
        }, 400);
      }

      const pickupLocation = String(process.env.SHIPROCKET_PICKUP_LOCATION || '').trim();
      if (!pickupLocation) {
        return jsonResponse({
          success: false,
          error: 'SHIPROCKET_PICKUP_LOCATION is not configured on Netlify.',
        }, 400);
      }

      const address = order.shippingAddress || {};
      const { first, last } = splitName(address.fullName);
      const paymentMethod = order.paymentMethod === 'cod' ? 'COD' : 'Prepaid';
      const packageWeight = Math.max(0.5, Number(process.env.SHIPROCKET_WEIGHT_KG || 0.5));
      const length = Math.max(1, Number(process.env.SHIPROCKET_LENGTH_CM || 20));
      const breadth = Math.max(1, Number(process.env.SHIPROCKET_BREADTH_CM || 15));
      const height = Math.max(1, Number(process.env.SHIPROCKET_HEIGHT_CM || 10));

      const orderItems = (Array.isArray(order.items) ? order.items : []).map((item, index) => ({
        name: String(item?.product?.name || `Product ${index + 1}`),
        sku: String(item?.product?.id || `${order.orderNumber || order.id}-${index + 1}`),
        units: Math.max(1, Number(item?.quantity || 1)),
        selling_price: Number(item?.product?.discountPrice || 0) * Number(item?.selectedLength?.priceMultiplier || 1),
        discount: 0,
        tax: 0,
        hsn: '',
      }));

      if (!orderItems.length) {
        return jsonResponse({ success: false, error: 'Order has no items to send to Shiprocket.' }, 400);
      }

      const payload = {
        order_id: String(order.orderNumber || order.id),
        order_date: shiprocketOrderDate(order),
        pickup_location: pickupLocation,
        comment: `Shree Maruti Krupa website order ${order.orderNumber || order.id}`,
        billing_customer_name: first,
        billing_last_name: last,
        billing_address: String(address.houseFlat || ''),
        billing_address_2: String(address.roadArea || ''),
        billing_city: String(address.city || ''),
        billing_pincode: String(address.pincode || ''),
        billing_state: String(address.state || ''),
        billing_country: 'India',
        billing_email: String(order.customerEmail || 'support@shreemarutikrupa.com'),
        billing_phone: String(address.phoneNumber || ''),
        shipping_is_billing: true,
        shipping_customer_name: first,
        shipping_last_name: last,
        shipping_address: String(address.houseFlat || ''),
        shipping_address_2: String(address.roadArea || ''),
        shipping_city: String(address.city || ''),
        shipping_pincode: String(address.pincode || ''),
        shipping_country: 'India',
        shipping_state: String(address.state || ''),
        shipping_email: String(order.customerEmail || 'support@shreemarutikrupa.com'),
        shipping_phone: String(address.phoneNumber || ''),
        order_items: orderItems,
        payment_method: paymentMethod,
        shipping_charges: Number(order.deliveryFee || 0),
        giftwrap_charges: 0,
        transaction_charges: 0,
        total_discount: Number(order.discount || 0),
        sub_total: Number(order.totalPayable || order.subtotal || 0),
        length,
        breadth,
        height,
        weight: packageWeight,
      };

      const sr = await shiprocketRequest('/orders/create/adhoc', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      const srOrderId = sr?.order_id ?? sr?.data?.order_id;
      const srShipmentId = sr?.shipment_id ?? sr?.data?.shipment_id;
      if (!srOrderId || !srShipmentId) {
        throw new Error('Shiprocket did not return order_id and shipment_id.');
      }

      const updatedOrder = {
        ...order,
        shiprocketOrderId: String(srOrderId),
        shiprocketShipmentId: String(srShipmentId),
        shiprocketStatus: 'created',
        shiprocketAwbCode: '',
        shiprocketCourierName: '',
        updatedAt: new Date().toISOString(),
      };

      return jsonResponse({
        success: true,
        alreadyCreated: false,
        order: updatedOrder,
        shiprocket: {
          orderId: String(srOrderId),
          shipmentId: String(srShipmentId),
          awbCode: '',
          courierName: '',
        },
      });
    } catch (error) {
      console.error('Shiprocket create order error:', error);
      return jsonResponse({
        success: false,
        error: error?.message || 'Failed to create Shiprocket order.',
      }, 500);
    }
  }

  return jsonResponse({ success: false, error: 'Not found' }, 404);
}
