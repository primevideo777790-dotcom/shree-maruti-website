import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { 
  User, 
  Phone, 
  Package, 
  Heart, 
  HelpCircle, 
  Languages, 
  LogOut, 
  LogIn, 
  ShieldCheck, 
  MapPin, 
  CheckCircle2,
  ChevronRight
} from 'lucide-react';

export const AccountView: React.FC = () => {
  const { user, loginUser, logoutUser, language, setLanguage, setActiveTab, openModal, orders, navigate } = useShop();

  const [inputName, setInputName] = useState(user.name || '');
  const [inputPhone, setInputPhone] = useState(user.phone || '');
  const [isEditing, setIsEditing] = useState(false);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputPhone.trim().length >= 10) {
      loginUser(inputName || 'Customer', inputPhone);
      setIsEditing(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Profile Card */}
      <div className="bg-white rounded-2xl border border-[#E5E0D8] p-5 sm:p-6 shadow-2xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[#111111] text-[#C8A96B] flex items-center justify-center text-xl font-bold shadow-xs border border-[#2B2B2B]">
            {user.isLoggedIn ? user.name.charAt(0).toUpperCase() : <User className="w-7 h-7" />}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg sm:text-xl font-black text-[#111111] truncate">
              {user.isLoggedIn ? user.name : (language === 'hi' ? 'अतिथि ग्राहक (Guest)' : 'Guest Customer')}
            </h2>
            <p className="text-xs sm:text-sm text-[#777777] font-mono flex items-center gap-1 mt-0.5">
              <Phone className="w-3.5 h-3.5 text-[#C8A96B]" />
              {user.isLoggedIn ? `+91 ${user.phone}` : (language === 'hi' ? 'मोबाइल नंबर नहीं जुड़ा है' : 'No phone linked')}
            </p>
          </div>
          <div>
            {user.isLoggedIn ? (
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs font-bold text-[#111111] hover:text-[#C8A96B] bg-[#F7F5F0] px-3 py-1.5 rounded-lg border border-[#E5E0D8] cursor-pointer transition"
              >
                {isEditing ? (language === 'hi' ? 'रद्द करें' : 'Cancel') : (language === 'hi' ? 'बदलें' : 'Edit')}
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="bg-[#111111] hover:bg-[#2B2B2B] text-white text-xs font-bold px-3.5 py-1.5 rounded-xl cursor-pointer shadow-xs transition"
              >
                {language === 'hi' ? 'लॉगिन करें' : 'Login'}
              </button>
            )}
          </div>
        </div>

        {/* Edit / Quick Login Form */}
        {(!user.isLoggedIn || isEditing) && (
          <form onSubmit={handleLoginSubmit} className="mt-4 pt-4 border-t border-[#E5E0D8] space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold text-[#111111] mb-1">
                  {language === 'hi' ? 'आपका नाम:' : 'Your Name:'}
                </label>
                <input
                  type="text"
                  value={inputName}
                  onChange={(e) => setInputName(e.target.value)}
                  placeholder="e.g. Ramesh Patel"
                  className="w-full px-3 py-2 text-xs bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#111111] mb-1">
                  {language === 'hi' ? '10-अंकों का मोबाइल नंबर:' : '10-Digit Mobile Number:'}
                </label>
                <input
                  type="tel"
                  maxLength={10}
                  value={inputPhone}
                  onChange={(e) => setInputPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="w-full px-3 py-2 text-xs bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] font-mono text-[#111111]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-2.5 px-4 rounded-xl text-xs transition cursor-pointer"
            >
              {language === 'hi' ? 'सुरक्षित सहेजें (Save Profile)' : 'Save Profile & Login'}
            </button>
          </form>
        )}
      </div>

      {/* Quick Access Menu List */}
      <div className="bg-white rounded-2xl border border-[#E5E0D8] overflow-hidden shadow-2xs divide-y divide-[#E5E0D8]">
        {/* My Orders */}
        <button
          onClick={() => setActiveTab('orders')}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#F7F5F0] transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center text-[#111111]">
              <Package className="w-5 h-5 text-[#C8A96B]" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#111111]">
                {language === 'hi' ? 'मेरे ऑर्डर व ट्रैकिंग (My Orders)' : 'My Orders & Tracking'}
              </h4>
              <p className="text-xs text-[#777777]">
                {orders.length} {language === 'hi' ? 'ऑर्डर दर्ज हैं' : 'orders placed'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#777777]" />
        </button>

        {/* Wishlist */}
        <button
          onClick={() => setActiveTab('wishlist')}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#F7F5F0] transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center text-[#9B2C2C]">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#111111]">
                {language === 'hi' ? 'पसंदीदा कपड़े (Wishlist)' : 'Saved Fabrics (Wishlist)'}
              </h4>
              <p className="text-xs text-[#777777]">
                {language === 'hi' ? 'आपके द्वारा सहेजे गए कपड़े देखें' : 'View fabrics you saved'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#777777]" />
        </button>

        {/* Help & Support */}
        <button
          onClick={() => openModal('support')}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#F7F5F0] transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center text-[#111111]">
              <HelpCircle className="w-5 h-5 text-[#C8A96B]" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#111111]">
                {language === 'hi' ? 'सहायता केंद्र व व्हाट्सएप (Help & Support)' : 'Customer Help & WhatsApp'}
              </h4>
              <p className="text-xs text-[#777777]">
                1800-200-5588 • {language === 'hi' ? 'सुबह 9 से रात 8 बजे तक' : '9 AM to 8 PM'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#777777]" />
        </button>

        {/* Language Switch */}
        <button
          onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-[#F7F5F0] transition cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center text-[#111111]">
              <Languages className="w-5 h-5 text-[#C8A96B]" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#111111]">
                {language === 'hi' ? 'भाषा (Language): हिंदी' : 'Language: English'}
              </h4>
              <p className="text-xs text-[#777777]">
                {language === 'hi' ? 'Click to change to English' : 'हिंदी में बदलने के लिए यहाँ दबाएं'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-[#111111] bg-[#F7F5F0] px-2.5 py-1 rounded-md border border-[#E5E0D8]">
            {language === 'en' ? 'Switch to हिंदी' : 'Switch to EN'}
          </span>
        </button>
        {/* Admin Portal Gateway */}
        <button
          onClick={() => navigate('/admin')}
          className="w-full p-4 flex items-center justify-between text-left bg-[#111111] text-white rounded-2xl border border-[#2B2B2B] hover:bg-[#2B2B2B] transition cursor-pointer shadow-sm"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#1E1E1E] border border-[#333333] flex items-center justify-center text-[#C8A96B]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Store Owner & Admin Portal</span>
                <span className="text-[10px] bg-[#2B2B2B] text-[#C8A96B] px-1.5 py-0.2 rounded font-mono border border-[#C8A96B]/30">/admin</span>
              </h4>
              <p className="text-xs text-[#D9D4CA]">
                Order fulfillment, fabric stock management & live analytics
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#D9D4CA]" />
        </button>
      </div>

      {/* Logout option */}
      {user.isLoggedIn && (
        <button
          onClick={logoutUser}
          className="w-full py-3 px-4 rounded-xl border border-[#9B2C2C]/30 text-[#9B2C2C] hover:bg-[#9B2C2C]/5 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>{language === 'hi' ? 'लॉगआउट करें (Sign Out)' : 'Log Out from this Device'}</span>
        </button>
      )}

      {/* Trust Guarantee Footer */}
      <div className="text-center p-4 bg-[#F7F5F0] rounded-2xl border border-[#E5E0D8] text-xs text-[#4A4A4A] space-y-1">
        <span className="font-bold text-[#111111] block">SHREE MARUTI KRUPA TEXTILE TRADERS</span>
        <p>{language === 'hi' ? 'सूरत, गुजरात • 100% शुद्ध कॉटन व लक्जरी फैब्रिक' : 'Surat, Gujarat • 100% Pure Genuine Textile Guarantee'}</p>
      </div>
    </div>
  );
};
