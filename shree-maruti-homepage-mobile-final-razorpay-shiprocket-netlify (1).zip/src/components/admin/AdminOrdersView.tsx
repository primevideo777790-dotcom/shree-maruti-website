import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { Order, OrderStatus } from '../../types';
import { 
  Package, 
  Search, 
  Filter, 
  Eye, 
  Printer, 
  Truck, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  MapPin, 
  Phone, 
  Calendar,
  AlertCircle,
  Edit2,
  X,
  Check,
  RotateCcw
} from 'lucide-react';
import { AdminInvoiceModal } from './AdminInvoiceModal';

export const AdminOrdersView: React.FC = () => {
  const { 
    orders, 
    updateOrderStatus, 
    updateOrderTracking, 
    createShiprocketOrder,
    updatePaymentStatus, 
    cancelOrder 
  } = useShop();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrderForInvoice, setSelectedOrderForInvoice] = useState<Order | null>(null);
  const [selectedOrderForModal, setSelectedOrderForModal] = useState<Order | null>(null);

  // Quick Tracking Edit state
  const [editingTrackingOrderId, setEditingTrackingOrderId] = useState<string | null>(null);
  const [editCourier, setEditCourier] = useState('');
  const [editTrackingNumber, setEditTrackingNumber] = useState('');
  const [editExpectedDate, setEditExpectedDate] = useState('');

  // Cancel order prompt state
  const [cancellingOrderId, setCancellingOrderId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('Out of fabric stock in Surat warehouse');

  const filteredOrders = orders.filter(ord => {
    // Status filter
    if (statusFilter !== 'all' && ord.status !== statusFilter) {
      return false;
    }

    // Search filter
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      const matchOrderNum = ord.orderNumber.toLowerCase().includes(q);
      const matchName = ord.shippingAddress.fullName.toLowerCase().includes(q);
      const matchPhone = ord.shippingAddress.phoneNumber.includes(q);
      const matchCity = ord.shippingAddress.city.toLowerCase().includes(q);
      const matchProduct = ord.items.some(i => i.product.name.toLowerCase().includes(q));

      return matchOrderNum || matchName || matchPhone || matchCity || matchProduct;
    }

    return true;
  });

  // Status update loading state
  const [updatingOrderId, setUpdatingOrderId] = useState<string | null>(null);
  const [shiprocketOrderId, setShiprocketOrderId] = useState<string | null>(null);

  const handleCreateShiprocket = async (ord: Order) => {
    if (shiprocketOrderId) return;
    setShiprocketOrderId(ord.id);
    try {
      const result = await createShiprocketOrder(ord.id);
      if (!result.success) {
        window.alert(result.error || 'Shiprocket order creation failed.');
      } else {
        window.alert(
          `Shiprocket order created successfully.\\n\\nOrder ID: ${result.shiprocket?.orderId || '—'}\\nShipment ID: ${result.shiprocket?.shipmentId || '—'}`
        );
      }
    } finally {
      setShiprocketOrderId(null);
    }
  };

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    setUpdatingOrderId(orderId);
    try {
      await updateOrderStatus(orderId, newStatus);
    } finally {
      setUpdatingOrderId(null);
    }
  };

  const handleStartEditTracking = (ord: Order) => {
    setEditingTrackingOrderId(ord.id);
    setEditCourier(ord.courierName);
    setEditTrackingNumber(ord.trackingNumber);
    setEditExpectedDate(ord.expectedDelivery);
  };

  const handleSaveTracking = async (orderId: string) => {
    await updateOrderTracking(orderId, editCourier, editTrackingNumber, editExpectedDate);
    setEditingTrackingOrderId(null);
  };

  const handleConfirmCancel = async () => {
    if (cancellingOrderId) {
      await cancelOrder(cancellingOrderId, cancelReason);
      setCancellingOrderId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-stone-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-serif">
            Order Management & Fulfillment
          </h1>
          <p className="text-xs text-stone-400 mt-0.5">
            Total {orders.length} customer orders • 1-click status progression and invoice printing
          </p>
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-72">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by order #, customer, phone..."
            className="w-full pl-9 pr-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
          />
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'All Orders', count: orders.length },
          { id: 'placed', label: 'Placed', count: orders.filter(o => o.status === 'placed').length },
          { id: 'confirmed', label: 'Confirmed', count: orders.filter(o => o.status === 'confirmed').length },
          { id: 'packed', label: 'Packed', count: orders.filter(o => o.status === 'packed').length },
          { id: 'shipped', label: 'Shipped', count: orders.filter(o => o.status === 'shipped').length },
          { id: 'out_for_delivery', label: 'Out for Delivery', count: orders.filter(o => o.status === 'out_for_delivery').length },
          { id: 'delivered', label: 'Delivered', count: orders.filter(o => o.status === 'delivered').length },
          { id: 'cancelled', label: 'Cancelled', count: orders.filter(o => o.status === 'cancelled').length }
        ].map((tab) => {
          const isActive = statusFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                isActive
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                isActive ? 'bg-amber-950 text-amber-200' : 'bg-stone-800 text-stone-500'
              }`}>
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Orders Table Container */}
      <div className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-sm">
        {filteredOrders.length === 0 ? (
          <div className="py-12 text-center text-stone-400 text-xs">
            <Package className="w-10 h-10 text-stone-600 mx-auto mb-2" />
            <p className="font-bold text-stone-300">No orders found matching this filter</p>
            <p className="text-[11px] text-stone-500 mt-1">Try resetting the search query or status filter.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-950 text-stone-400 text-[11px] uppercase tracking-wider border-b border-stone-800">
                <tr>
                  <th className="py-3 px-4">Order ID & Date</th>
                  <th className="py-3 px-4">Customer Details</th>
                  <th className="py-3 px-4">Products & Cut</th>
                  <th className="py-3 px-4">Amount & Payment</th>
                  <th className="py-3 px-4">Delivery & Courier</th>
                  <th className="py-3 px-4">Order Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/80 text-stone-300">
                {filteredOrders.map((ord) => {
                  return (
                    <tr key={ord.id} className="hover:bg-stone-850/60 transition">
                      {/* Order ID & Date */}
                      <td className="py-3.5 px-4 font-mono">
                        <span className="font-bold text-amber-400 block text-xs">
                          #{ord.orderNumber}
                        </span>
                        <span className="text-[11px] text-stone-400 flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3 h-3 text-stone-500" />
                          {ord.date}
                        </span>
                      </td>

                      {/* Customer Info */}
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-white block">
                          {ord.shippingAddress.fullName}
                        </span>
                        <span className="text-[11px] text-stone-400 font-mono flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-stone-500" />
                          +91 {ord.shippingAddress.phoneNumber}
                        </span>
                        <span className="text-[10px] text-stone-500 truncate max-w-[150px] block mt-0.5">
                          {ord.shippingAddress.city}, {ord.shippingAddress.state} ({ord.shippingAddress.pincode})
                        </span>
                      </td>

                      {/* Products Summary */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          {ord.items.map((item, idx) => (
                            <div key={idx} className="flex items-center gap-1.5">
                              <span className="font-bold text-[10px] text-amber-400 bg-stone-900 border border-stone-800 px-1.5 py-0.2 rounded shrink-0">
                                {item.selectedLength.label.split('-')[0].trim()}
                              </span>
                              <span className="font-medium text-stone-200 truncate max-w-[170px]">
                                {item.quantity}x {item.product.name}
                              </span>
                            </div>
                          ))}
                        </div>
                      </td>

                      {/* Amount & Payment Status */}
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-white text-sm block">
                          ₹{ord.totalPayable}
                        </span>
                        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                          <span className={`text-[10px] font-bold uppercase px-1.5 py-0.2 rounded ${
                            ord.paymentMethod === 'phonepe'
                              ? 'bg-purple-950 text-purple-300 border border-purple-800'
                              : 'bg-stone-800 text-stone-400'
                          }`}>
                            {ord.paymentMethod === 'phonepe' ? 'PhonePe' : ord.paymentMethod}
                          </span>
                          <span className={`text-[10px] font-bold uppercase px-1.5 py-0.2 rounded border ${
                            ord.paymentStatus === 'paid' 
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-800' 
                              : ord.paymentStatus === 'failed'
                              ? 'bg-red-950 text-red-300 border-red-800'
                              : ord.paymentStatus === 'cancelled'
                              ? 'bg-stone-800 text-stone-400 border-stone-700'
                              : 'bg-amber-950 text-amber-300 border-amber-800'
                          }`}>
                            {ord.paymentStatus === 'paid' ? 'Paid' : ord.paymentStatus === 'failed' ? 'Failed' : ord.paymentStatus === 'cancelled' ? 'Cancelled' : 'Pending'}
                          </span>
                        </div>
                        {ord.paymentRef && (
                          <span className="font-mono text-[9px] text-stone-400 block mt-0.5 truncate max-w-[140px]" title={ord.paymentRef}>
                            Ref: {ord.paymentRef}
                          </span>
                        )}
                        {ord.shiprocketOrderId && (
                          <span className="font-mono text-[9px] text-emerald-400 block mt-1 truncate max-w-[160px]" title="Shiprocket Order ID">
                            SR Order: {ord.shiprocketOrderId}
                          </span>
                        )}
                        {ord.shiprocketShipmentId && (
                          <span className="font-mono text-[9px] text-cyan-400 block truncate max-w-[160px]" title="Shiprocket Shipment ID">
                            SR Shipment: {ord.shiprocketShipmentId}
                          </span>
                        )}
                      </td>

                      {/* Courier & Tracking */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1 text-[11px] text-stone-200">
                            <Truck className="w-3 h-3 text-amber-400" />
                            <span className="font-semibold">{ord.courierName.split(' ')[0]}</span>
                          </div>
                          <span className="font-mono text-[10px] text-stone-400 block">
                            {ord.trackingNumber}
                          </span>
                          <button
                            onClick={() => handleStartEditTracking(ord)}
                            className="text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                          >
                            <Edit2 className="w-2.5 h-2.5" />
                            <span>Edit AWB</span>
                          </button>
                        </div>
                      </td>

                      {/* Status & 1-Click Fast Progress */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-1.5 min-w-[140px]">
                          {/* 1-Click Fast Stepper Button */}
                          {ord.status === 'placed' && (
                            <button
                              disabled={updatingOrderId === ord.id}
                              onClick={() => handleUpdateStatus(ord.id, 'confirmed')}
                              className="w-full bg-cyan-700 hover:bg-cyan-600 disabled:opacity-50 text-white font-bold py-1 px-2 rounded-lg text-[11px] shadow-xs cursor-pointer flex items-center justify-center gap-1"
                              title="Advance to Confirmed"
                            >
                              <span>{updatingOrderId === ord.id ? 'Saving...' : '✓ Confirm Order'}</span>
                            </button>
                          )}
                          {ord.status === 'confirmed' && (
                            <button
                              disabled={updatingOrderId === ord.id}
                              onClick={() => handleUpdateStatus(ord.id, 'packed')}
                              className="w-full bg-purple-700 hover:bg-purple-600 disabled:opacity-50 text-white font-bold py-1 px-2 rounded-lg text-[11px] shadow-xs cursor-pointer flex items-center justify-center gap-1"
                              title="Advance to Packed"
                            >
                              <span>{updatingOrderId === ord.id ? 'Saving...' : '📦 Mark Packed'}</span>
                            </button>
                          )}
                          {ord.status === 'packed' && (
                            <button
                              disabled={updatingOrderId === ord.id}
                              onClick={() => handleUpdateStatus(ord.id, 'shipped')}
                              className="w-full bg-blue-700 hover:bg-blue-600 disabled:opacity-50 text-white font-bold py-1 px-2 rounded-lg text-[11px] shadow-xs cursor-pointer flex items-center justify-center gap-1"
                              title="Advance to Shipped"
                            >
                              <span>{updatingOrderId === ord.id ? 'Saving...' : '🚚 Mark Shipped'}</span>
                            </button>
                          )}
                          {ord.status === 'shipped' && (
                            <button
                              disabled={updatingOrderId === ord.id}
                              onClick={() => handleUpdateStatus(ord.id, 'out_for_delivery')}
                              className="w-full bg-indigo-700 hover:bg-indigo-600 disabled:opacity-50 text-white font-bold py-1 px-2 rounded-lg text-[11px] shadow-xs cursor-pointer flex items-center justify-center gap-1"
                              title="Advance to Out for Delivery"
                            >
                              <span>{updatingOrderId === ord.id ? 'Saving...' : '🛵 Out for Delivery'}</span>
                            </button>
                          )}
                          {ord.status === 'out_for_delivery' && (
                            <button
                              disabled={updatingOrderId === ord.id}
                              onClick={() => handleUpdateStatus(ord.id, 'delivered')}
                              className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold py-1 px-2 rounded-lg text-[11px] shadow-xs cursor-pointer flex items-center justify-center gap-1"
                              title="Advance to Delivered"
                            >
                              <span>{updatingOrderId === ord.id ? 'Saving...' : '🎉 Mark Delivered'}</span>
                            </button>
                          )}
                          {ord.status === 'delivered' && (
                            <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Delivered</span>
                            </span>
                          )}
                          {ord.status === 'cancelled' && (
                            <span className="text-[11px] font-bold text-red-400 flex items-center gap-1">
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Cancelled</span>
                            </span>
                          )}

                          {/* Dropdown for manual override */}
                          <select
                            disabled={updatingOrderId === ord.id}
                            value={ord.status}
                            onChange={(e) => handleUpdateStatus(ord.id, e.target.value as OrderStatus)}
                            className="w-full text-[10px] font-semibold py-0.5 px-1.5 rounded bg-stone-950 border border-stone-800 text-stone-400 focus:outline-none cursor-pointer disabled:opacity-50"
                          >
                            <option value="placed">Placed</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="packed">Packed</option>
                            <option value="shipped">Shipped</option>
                            <option value="out_for_delivery">Out for Delivery</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Shiprocket */}
                          <button
                            onClick={() => handleCreateShiprocket(ord)}
                            disabled={Boolean(ord.shiprocketOrderId) || shiprocketOrderId === ord.id}
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-xs ${
                              ord.shiprocketOrderId
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 cursor-default'
                                : shiprocketOrderId === ord.id
                                ? 'bg-stone-800 text-stone-500 cursor-wait'
                                : 'bg-purple-900/90 hover:bg-purple-800 text-purple-200 cursor-pointer'
                            }`}
                            title={ord.shiprocketOrderId ? 'Already created in Shiprocket' : 'Create order in Shiprocket'}
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>{shiprocketOrderId === ord.id ? 'Creating…' : ord.shiprocketOrderId ? 'Shiprocket ✓' : 'Shiprocket'}</span>
                          </button>

                          {/* Print Invoice */}
                          <button
                            onClick={() => setSelectedOrderForInvoice(ord)}
                            className="px-2.5 py-1.5 rounded-lg bg-amber-900/90 hover:bg-amber-800 text-amber-200 text-xs font-bold transition cursor-pointer flex items-center gap-1 shadow-xs"
                            title="Print Tax Invoice / Bill"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Invoice</span>
                          </button>

                          {/* View details */}
                          <button
                            onClick={() => setSelectedOrderForModal(ord)}
                            className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 transition cursor-pointer"
                            title="View full order details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Cancel Order */}
                          {ord.status !== 'cancelled' && ord.status !== 'delivered' && (
                            <button
                              onClick={() => setCancellingOrderId(ord.id)}
                              className="p-1.5 rounded-lg bg-stone-800 hover:bg-red-950 hover:text-red-400 text-stone-400 transition cursor-pointer"
                              title="Cancel this order"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Tracking Modal */}
      {editingTrackingOrderId && (
        <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-stone-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-400" />
                Update Logistics & AWB
              </h3>
              <button 
                onClick={() => setEditingTrackingOrderId(null)}
                className="text-stone-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-400 font-bold mb-1">Courier Partner Name</label>
                <input
                  type="text"
                  value={editCourier}
                  onChange={(e) => setEditCourier(e.target.value)}
                  placeholder="e.g. Delhivery, Blue Dart, DTDC"
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-stone-400 font-bold mb-1">AWB / Tracking Number</label>
                <input
                  type="text"
                  value={editTrackingNumber}
                  onChange={(e) => setEditTrackingNumber(e.target.value)}
                  placeholder="e.g. DLHV-102938475"
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-stone-400 font-bold mb-1">Expected Delivery Date / Window</label>
                <input
                  type="text"
                  value={editExpectedDate}
                  onChange={(e) => setEditExpectedDate(e.target.value)}
                  placeholder="e.g. In 2 Days, 26 Sep by 6 PM"
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setEditingTrackingOrderId(null)}
                className="px-3 py-2 rounded-xl bg-stone-800 text-stone-300 text-xs font-bold hover:bg-stone-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveTracking(editingTrackingOrderId)}
                className="px-4 py-2 rounded-xl bg-amber-800 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer"
              >
                Save Tracking Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Order Confirmation Modal */}
      {cancellingOrderId && (
        <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-red-900/60 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2.5 text-red-400">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold text-white">Cancel Order Confirmation</h3>
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              Are you sure you want to cancel this order? This will mark the order as Cancelled and automatically restore the reserved meters to inventory.
            </p>

            <div>
              <label className="block text-xs font-bold text-stone-400 mb-1">Cancellation Reason</label>
              <input
                type="text"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Reason for cancellation"
                className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white text-xs"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setCancellingOrderId(null)}
                className="px-3 py-2 rounded-xl bg-stone-800 text-stone-300 text-xs font-bold hover:bg-stone-700 cursor-pointer"
              >
                No, Keep Order
              </button>
              <button
                onClick={handleConfirmCancel}
                className="px-4 py-2 rounded-xl bg-red-800 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full Order Detail Modal */}
      {selectedOrderForModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl max-w-2xl w-full p-6 space-y-5 text-xs text-stone-300 shadow-2xl my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div>
                <h3 className="text-base font-bold text-white">
                  Order Details — #{selectedOrderForModal.orderNumber}
                </h3>
                <p className="text-stone-400 font-mono text-[11px]">Placed on {selectedOrderForModal.date}</p>
              </div>
              <button
                onClick={() => setSelectedOrderForModal(null)}
                className="p-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Address & Logistics Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-stone-950 p-4 rounded-xl border border-stone-800">
              <div>
                <span className="font-bold text-white uppercase text-[10px] tracking-wider block mb-1">
                  Customer Shipping Address
                </span>
                <p className="font-bold text-amber-400">{selectedOrderForModal.shippingAddress.fullName}</p>
                <p className="font-mono text-stone-400">+91 {selectedOrderForModal.shippingAddress.phoneNumber}</p>
                <p className="text-stone-300 mt-1">
                  {selectedOrderForModal.shippingAddress.houseFlat}, {selectedOrderForModal.shippingAddress.roadArea}
                </p>
                <p className="text-stone-300">
                  {selectedOrderForModal.shippingAddress.city}, {selectedOrderForModal.shippingAddress.state} - {selectedOrderForModal.shippingAddress.pincode}
                </p>
              </div>

              <div className="border-t sm:border-t-0 sm:border-l border-stone-800 pt-3 sm:pt-0 sm:pl-4">
                <span className="font-bold text-white uppercase text-[10px] tracking-wider block mb-1">
                  Payment & Delivery Status
                </span>
                <p className="text-stone-300">
                  Mode: <span className="font-bold uppercase text-white">{selectedOrderForModal.paymentMethod}</span> ({selectedOrderForModal.paymentStatus})
                </p>
                <p className="text-stone-300 mt-0.5">
                  Courier: <span className="font-semibold text-white">{selectedOrderForModal.courierName}</span>
                </p>
                <p className="font-mono text-stone-400">AWB: {selectedOrderForModal.trackingNumber}</p>
                <p className="text-stone-300 mt-0.5">Expected: {selectedOrderForModal.expectedDelivery}</p>
              </div>
            </div>

            {selectedOrderForModal.shiprocketOrderId && (
              <div className="bg-stone-950 p-4 rounded-xl border border-emerald-900/50">
                <span className="font-bold text-emerald-300 uppercase text-[10px] tracking-wider block mb-2">
                  Shiprocket Fulfillment
                </span>
                <div className="grid grid-cols-2 gap-2 font-mono text-[10px]">
                  <span>Order ID: <b className="text-white">{selectedOrderForModal.shiprocketOrderId}</b></span>
                  <span>Shipment ID: <b className="text-white">{selectedOrderForModal.shiprocketShipmentId || '—'}</b></span>
                  <span>AWB: <b className="text-white">{selectedOrderForModal.shiprocketAwbCode || 'Not assigned yet'}</b></span>
                  <span>Courier: <b className="text-white">{selectedOrderForModal.shiprocketCourierName || 'Not assigned yet'}</b></span>
                </div>
              </div>
            )}

            {/* Items */}
            <div className="space-y-2">
              <span className="font-bold text-white uppercase text-[10px] tracking-wider block">
                Fabrics Ordered
              </span>
              <div className="divide-y divide-stone-800 border border-stone-800 rounded-xl overflow-hidden bg-stone-950">
                {selectedOrderForModal.items.map((item, i) => (
                  <div key={i} className="p-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img 
                        src={item.product.image} 
                        alt={item.product.name} 
                        className="w-12 h-12 rounded-lg object-cover border border-stone-800" 
                      />
                      <div>
                        <h4 className="font-bold text-white">{item.product.name}</h4>
                        <p className="text-[11px] text-stone-400 mt-0.5">
                          Size: <span className="text-amber-400 font-bold">{item.selectedLength.label.split('-')[0].trim()}</span> • {item.selectedLength.suitableFor}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-white text-sm block">
                        ₹{Math.round(item.product.discountPrice * item.selectedLength.priceMultiplier) * item.quantity}
                      </span>
                      <span className="text-[10px] text-stone-500">Qty: {item.quantity}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Total */}
            <div className="bg-stone-950 p-3 rounded-xl border border-stone-800 flex justify-between items-center text-sm">
              <span className="font-bold text-stone-300">Total Billed Amount:</span>
              <span className="font-black text-amber-400 text-base">₹{selectedOrderForModal.totalPayable}</span>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setSelectedOrderForInvoice(selectedOrderForModal);
                  setSelectedOrderForModal(null);
                }}
                className="bg-amber-800 hover:bg-amber-700 text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Invoice</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Modal Preview */}
      {selectedOrderForInvoice && (
        <AdminInvoiceModal
          order={selectedOrderForInvoice}
          onClose={() => setSelectedOrderForInvoice(null)}
        />
      )}
    </div>
  );
};
