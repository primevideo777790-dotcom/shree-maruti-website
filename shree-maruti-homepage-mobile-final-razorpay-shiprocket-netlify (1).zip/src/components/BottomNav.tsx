import React from 'react';
import { SlidersHorizontal, ArrowDownUp } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const toggleFilter = () => window.dispatchEvent(new Event('smk:toggle-filters'));
  const sortProducts = () => window.dispatchEvent(new Event('smk:sort-products'));

  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-[#D9D9D9] shadow-[0_-3px_12px_rgba(0,0,0,0.08)] h-[58px]">
      <div className="h-full grid grid-cols-2 divide-x divide-[#D9D9D9]">
        <button onClick={toggleFilter} className="flex items-center justify-center gap-2 text-[14px] font-medium text-[#111111] active:bg-[#F5F5F5]">
          <SlidersHorizontal className="w-5 h-5" strokeWidth={1.7} />
          Filter By Category
        </button>
        <button onClick={sortProducts} className="flex items-center justify-center gap-2 text-[14px] font-medium text-[#111111] active:bg-[#F5F5F5]">
          <ArrowDownUp className="w-5 h-5" strokeWidth={1.7} />
          Sort
        </button>
      </div>
    </div>
  );
};
