/**
 * Image Storage & Upload Service
 * Handles client-side device image validation, optimization, storage in IndexedDB / DataURL,
 * and realistic upload lifecycle with progress and error handling.
 */

export interface ImageUploadResult {
  url: string;
  id: string;
  name: string;
  size: number;
  type: string;
}

export interface ImageValidationResult {
  valid: boolean;
  error?: string;
}

const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp'];
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 Megabytes

/**
 * Validates selected file format, size, and validity
 */
export function validateImageFile(file: File | null | undefined): ImageValidationResult {
  if (!file) {
    return { valid: false, error: 'No file selected. Please select an image.' };
  }

  if (file.size === 0) {
    return { valid: false, error: 'The selected file is empty (0 bytes). Please choose a valid image.' };
  }

  const extension = file.name.split('.').pop()?.toLowerCase() || '';
  const hasValidExt = ALLOWED_EXTENSIONS.includes(extension);
  const hasValidMime = ALLOWED_MIME_TYPES.includes(file.type.toLowerCase());

  if (!hasValidExt && !hasValidMime) {
    return {
      valid: false,
      error: 'Invalid file format. Please upload JPG, JPEG, PNG, or WEBP image.'
    };
  }

  if (file.size > MAX_FILE_SIZE) {
    const sizeInMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `File is too large (${sizeInMb} MB). Maximum allowed size is 10 MB.`
    };
  }

  return { valid: true };
}

/**
 * Optimizes an image using HTML5 Canvas to keep storage lightweight
 * while preserving high fidelity (max 1400px width/height, 0.88 quality).
 */
export async function optimizeImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => {
      reject(new Error('Failed to read file from device'));
    };

    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => {
        reject(new Error('Failed to decode image data'));
      };

      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          let { width, height } = img;
          const maxDimension = 1400;

          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            // Fallback to original data URL if 2D context is unavailable
            resolve(e.target?.result as string);
            return;
          }

          // Use high quality image smoothing
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, width, height);

          // Output as webp if supported, or jpeg
          const format = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
          const optimizedDataUrl = canvas.toDataURL(format, 0.88);
          resolve(optimizedDataUrl);
        } catch {
          // If canvas fails, return original data URL
          resolve(e.target?.result as string);
        }
      };

      img.src = e.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}

/**
 * IndexedDB storage helper for persistent image caching
 */
const DB_NAME = 'smk_fabric_storage';
const STORE_NAME = 'uploaded_images';
const DB_VERSION = 1;

function openImageDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function storeImageInDB(id: string, dataUrl: string, metadata: { name: string; size: number; type: string }): Promise<void> {
  try {
    const db = await openImageDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put({ id, dataUrl, ...metadata, timestamp: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Gracefully ignore if indexedDB is restricted
  }
}

/**
 * Uploads an image file:
 * 1. Validates file format and size
 * 2. Optimizes image data
 * 3. Persists to storage
 * 4. Returns permanent storage URL and metadata
 */
export async function uploadImageFile(
  file: File,
  onProgress?: (progress: number) => void
): Promise<ImageUploadResult> {
  // 1. Validation
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error || 'Invalid image file');
  }

  // 2. Simulated progressive upload steps
  onProgress?.(15);
  await new Promise((r) => setTimeout(r, 80));

  onProgress?.(45);
  const optimizedDataUrl = await optimizeImage(file);

  onProgress?.(80);
  const imageId = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  
  await storeImageInDB(imageId, optimizedDataUrl, {
    name: file.name,
    size: file.size,
    type: file.type
  });

  // Upload to backend server for permanent, lightweight file storage
  let permanentUrl = '';
  try {
    const res = await fetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: optimizedDataUrl, name: file.name })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.success || !data.url) {
      throw new Error(data.error || `Image upload failed (${res.status})`);
    }
    permanentUrl = data.url;
  } catch (err) {
    console.error('Permanent image upload failed:', err);
    throw new Error('Image could not be saved to the website server. Please try the upload again.');
  }

  onProgress?.(100);
  await new Promise((r) => setTimeout(r, 60));

  return {
    url: permanentUrl,
    id: imageId,
    name: file.name,
    size: file.size,
    type: file.type
  };
}
