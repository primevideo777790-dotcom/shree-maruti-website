import React from 'react';
import { Order } from '../../types';
import { useShop } from '../../context/ShopContext';
import { X, Printer, Scissors, CheckCircle2, MapPin, Phone, Calendar } from 'lucide-react';

interface AdminInvoiceModalProps {
  order: Order;
  onClose: () => void;
}

export const AdminInvoiceModal: React.FC<AdminInvoiceModalProps> = ({ order, onClose }) => {
  const { storeSettings } = useShop();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full my-auto overflow-hidden shadow-2xl border border-stone-200">
        {/* Modal Top Actions */}
        <div className="p-4 border-b border-stone-200 bg-stone-50 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              Tax Invoice / Bill Preview
            </span>
            <span className="font-mono text-xs font-bold bg-stone-200 px-2 py-0.5 rounded text-stone-800">
              #{order.orderNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-amber-900 hover:bg-amber-950 text-white font-bold py-1.5 px-3 rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Invoice</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-700 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Sheet */}
        <div className="p-6 sm:p-8 space-y-6 text-stone-900 text-xs font-sans print:p-0">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-stone-200 pb-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-6 h-6 rounded bg-amber-900 text-amber-200 flex items-center justify-center">
                  <Scissors className="w-3.5 h-3.5 -rotate-45" />
                </div>
                <h1 className="text-base sm:text-lg font-black tracking-wide font-serif text-stone-900">
                  {storeSettings.tradeName || 'SHREE MARUTI KRUPA'}
                </h1>
              </div>
              <p className="text-[11px] text-stone-600">Textile & Suiting House, Surat</p>
              <p className="text-[11px] text-stone-500">{storeSettings.warehouseAddress}</p>
              <p className="text-[11px] text-stone-500">Toll Free: {storeSettings.tollFree} | {storeSettings.email}</p>
              <p className="text-[10px] text-stone-400 font-mono mt-0.5">GSTIN: {storeSettings.gstin}</p>
            </div>

            <div className="text-right">
              <span className="text-base font-extrabold text-amber-950 uppercase block">
                TAX INVOICE
              </span>
              <p className="font-mono font-bold text-stone-800 mt-1">Invoice #{order.orderNumber}</p>
              <p className="text-stone-500 mt-0.5">Date: {order.date}</p>
              <p className="text-stone-500">Payment: <span className="font-bold uppercase">{order.paymentMethod}</span></p>
              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold mt-1 uppercase ${
                order.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
              }`}>
                {order.paymentStatus === 'paid' ? 'PAID' : 'COD (PAY ON DELIVERY)'}
              </span>
            </div>
          </div>

          {/* Customer & Shipping Details */}
          <div className="grid grid-cols-2 gap-4 bg-stone-50 p-3.5 rounded-xl border border-stone-200 text-xs">
            <div>
              <span className="font-bold text-stone-500 uppercase tracking-wider text-[10px] block mb-1">
                Billed & Shipped To:
              </span>
              <p className="font-bold text-stone-900 text-sm">{order.shippingAddress.fullName}</p>
              <p className="text-stone-600 font-mono">+91 {order.shippingAddress.phoneNumber}</p>
              <p className="text-stone-600 mt-1">
                {order.shippingAddress.houseFlat}, {order.shippingAddress.roadArea}
              </p>
              <p className="text-stone-600">
                {order.shippingAddress.city}, {order.shippingAddress.state} - {order.shippingAddress.pincode}
              </p>
            </div>

            <div className="border-l border-stone-200 pl-4">
              <span className="font-bold text-stone-500 uppercase tracking-wider text-[10px] block mb-1">
                Logistics & Dispatch:
              </span>
              <p className="font-bold text-stone-800">{order.courierName}</p>
              <p className="text-stone-600 font-mono mt-0.5">AWB: {order.trackingNumber}</p>
              <p className="text-stone-600 mt-1">Delivery Speed: <span className="capitalize font-medium">{order.deliveryType} Delivery</span></p>
              <p className="text-stone-600">Expected: {order.expectedDelivery}</p>
            </div>
          </div>

          {/* Item Table */}
          <div className="border border-stone-200 rounded-xl overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-stone-100 text-stone-700 text-[11px] uppercase border-b border-stone-200">
                <tr>
                  <th className="py-2.5 px-3">Item Description</th>
                  <th className="py-2.5 px-3">Length / Cut</th>
                  <th className="py-2.5 px-3 text-center">Qty</th>
                  <th className="py-2.5 px-3 text-right">Rate</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-xs">
                {order.items.map((item, idx) => {
                  const unitRate = Math.round(item.product.discountPrice * item.selectedLength.priceMultiplier);
                  const lineTotal = unitRate * item.quantity;
                  return (
                    <tr key={idx} className="hover:bg-stone-50">
                      <td className="py-2.5 px-3 font-medium text-stone-900">
                        <div>{item.product.name}</div>
                        <div className="text-[11px] text-stone-500">{item.product.material}</div>
                      </td>
                      <td className="py-2.5 px-3 text-stone-600">
                        {item.selectedLength.label.split('-')[0]} ({item.selectedLength.lengthMeters}m)
                      </td>
                      <td className="py-2.5 px-3 text-center font-bold text-stone-800">{item.quantity}</td>
                      <td className="py-2.5 px-3 text-right text-stone-600">₹{unitRate}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-stone-900">₹{lineTotal}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-64 space-y-1.5 text-xs bg-stone-50 p-3.5 rounded-xl border border-stone-200">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal (MRP):</span>
                <span>₹{order.subtotal}</span>
              </div>
              <div className="flex justify-between text-emerald-700 font-medium">
                <span>Fabric Discount:</span>
                <span>- ₹{order.discount}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Delivery Charges:</span>
                <span>{order.deliveryFee === 0 ? 'FREE' : `₹${order.deliveryFee}`}</span>
              </div>
              <div className="border-t border-stone-200 pt-2 flex justify-between font-black text-sm text-stone-900">
                <span>Grand Total:</span>
                <span className="text-amber-950 font-bold">₹{order.totalPayable}</span>
              </div>
            </div>
          </div>

          {/* Footer declaration */}
          <div className="pt-4 border-t border-stone-200 flex justify-between items-end text-[10px] text-stone-400">
            <div>
              <p>Thank you for choosing SHREE MARUTI KRUPA.</p>
              <p>Certified 100% Genuine Textile Quality • Surat Textile Market</p>
            </div>
            <div className="text-right">
              <div className="border-b border-stone-300 w-32 mb-1"></div>
              <p className="font-semibold text-stone-600">Authorized Signatory</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
