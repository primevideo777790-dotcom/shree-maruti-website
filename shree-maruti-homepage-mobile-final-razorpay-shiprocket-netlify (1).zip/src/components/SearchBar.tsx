import React, { useState, useRef, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { Search, X, Clock, Flame, ChevronRight } from 'lucide-react';
import { POPULAR_SEARCHES } from '../data/products';

export const SearchBar: React.FC = () => {
  const { 
    searchQuery, 
    setSearchQuery, 
    recentSearches, 
    addRecentSearch, 
    clearRecentSearches, 
    t, 
    language,
    products,
    openModal,
    setSelectedCategory
  } = useShop();

  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectTerm = (term: string) => {
    setSearchQuery(term);
    addRecentSearch(term);
    setSelectedCategory('all');
    setIsOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      addRecentSearch(searchQuery);
      setSelectedCategory('all');
      setIsOpen(false);
    }
  };

  // Live matching products preview
  const previewProducts = searchQuery.trim()
    ? products.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.material.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 3)
    : [];

  return (
    <div ref={containerRef} className="relative w-full max-w-2xl">
      <div className="relative flex items-center">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#C8A96B] pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={t.searchPlaceholder}
          className="w-full pl-11 pr-10 py-2.5 sm:py-3 text-sm sm:text-base text-white bg-[#1C1C1C] border border-[#333333] rounded-xl focus:bg-[#242424] focus:outline-none focus:ring-1 focus:ring-[#C8A96B] focus:border-[#C8A96B] shadow-sm transition placeholder:text-[#777777] font-medium"
        />
        {searchQuery && (
          <button
            onClick={() => {
              setSearchQuery('');
              setIsOpen(true);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#777777] hover:text-white p-1 cursor-pointer"
            title="Clear search"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Search dropdown suggestions */}
      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-[#E5E0D8] z-50 overflow-hidden divide-y divide-[#E5E0D8] max-h-[80vh] overflow-y-auto">
          {/* Recent Searches */}
          {recentSearches.length > 0 && !searchQuery && (
            <div className="p-3">
              <div className="flex items-center justify-between text-xs font-semibold text-[#777777] mb-2 px-1">
                <span className="flex items-center gap-1.5 text-[#111111]">
                  <Clock className="w-3.5 h-3.5 text-[#C8A96B]" />
                  {language === 'hi' ? 'हाल की खोजें (Recent Searches)' : 'Recent Searches'}
                </span>
                <button 
                  onClick={clearRecentSearches}
                  className="text-[#777777] hover:text-[#111111] hover:underline cursor-pointer"
                >
                  {language === 'hi' ? 'हटाएं' : 'Clear all'}
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((term) => (
                  <button
                    key={term}
                    onClick={() => handleSelectTerm(term)}
                    className="px-3 py-1.5 text-xs sm:text-sm bg-[#F7F5F0] hover:bg-[#E5E0D8] text-[#4A4A4A] border border-[#E5E0D8] rounded-lg transition font-medium text-left cursor-pointer"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Popular Searches */}
          {!searchQuery && (
            <div className="p-3 bg-[#F7F5F0]">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#111111] mb-2 px-1">
                <Flame className="w-3.5 h-3.5 text-[#C8A96B]" />
                {language === 'hi' ? 'लोकप्रिय खोजें (Popular Searches)' : 'Popular Searches in Fabrics'}
              </div>
              <div className="flex flex-wrap gap-2">
                {POPULAR_SEARCHES.map((item) => (
                  <button
                    key={item}
                    onClick={() => handleSelectTerm(item)}
                    className="px-3 py-1.5 text-xs sm:text-sm bg-white border border-[#E5E0D8] text-[#111111] hover:border-[#C8A96B] hover:text-[#111111] rounded-lg transition font-medium text-left shadow-2xs cursor-pointer"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Real-time search preview matches */}
          {searchQuery && previewProducts.length > 0 && (
            <div className="p-2">
              <div className="text-xs font-semibold text-[#777777] px-2 py-1 uppercase tracking-wide">
                {language === 'hi' ? 'मिलते-जुलते कपड़े' : 'Matching Fabrics'}
              </div>
              {previewProducts.map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => {
                    openModal('product', prod);
                    setIsOpen(false);
                  }}
                  className="flex items-center gap-3 p-2 hover:bg-[#F7F5F0] rounded-lg cursor-pointer transition"
                >
                  <img 
                    src={prod.image} 
                    alt={prod.name} 
                    className="w-12 h-12 rounded-md object-cover border border-[#E5E0D8] shrink-0" 
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#111111] truncate">
                      {language === 'hi' ? prod.nameHi : prod.name}
                    </p>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold text-[#111111]">₹{prod.discountPrice}</span>
                      <span className="line-through text-[#777777]">₹{prod.originalPrice}</span>
                      <span className="text-[#9B2C2C] font-semibold">{prod.discountPercent}% OFF</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#777777]" />
                </div>
              ))}
            </div>
          )}

          {searchQuery && previewProducts.length === 0 && (
            <div className="p-4 text-center text-sm text-[#4A4A4A]">
              {language === 'hi' 
                ? 'कोई कपड़ा नहीं मिला। कृपया दूसरा नाम या "shirt", "pant", "cotton" खोजें।' 
                : 'No exact fabric found. Try searching "shirt", "pant", "linen" or "combo".'}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
