import React from 'react';
import { useShop } from '../context/ShopContext';
import { CheckCircle2, ShoppingBag, ArrowRight, X } from 'lucide-react';

export const AddToCartConfirmation: React.FC = () => {
  const { lastAddedItem, closeModal, openModal, cartCount, cartTotal, language } = useShop();

  if (!lastAddedItem) return null;

  const { product, selectedVariant, selectedLength, quantity } = lastAddedItem;
  const itemPrice = Math.round(product.discountPrice * selectedLength.priceMultiplier) * quantity;

  const handleContinue = () => {
    closeModal();
  };

  const handleViewCart = () => {
    closeModal();
    openModal('cartDrawer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-[#E5E0D8] relative animate-in fade-in zoom-in-95 duration-150">
        {/* Close Button */}
        <button
          onClick={handleContinue}
          className="absolute top-4 right-4 text-[#777777] hover:text-[#111111] p-1 cursor-pointer transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Success Header */}
        <div className="flex items-center gap-3 mb-4 pb-3 border-b border-[#E5E0D8]">
          <div className="w-10 h-10 rounded-full bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6 text-[#C8A96B]" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-[#111111] leading-tight">
              {language === 'hi' ? 'कपड़ा कार्ट में जोड़ दिया गया है!' : 'Added to Cart Successfully!'}
            </h2>
            <p className="text-xs text-[#777777]">
              {language === 'hi' ? 'आपकी खरीदारी सुरक्षित है' : 'Item is reserved in your shopping bag'}
            </p>
          </div>
        </div>

        {/* Item Summary Preview */}
        <div className="flex items-center gap-3 bg-[#F7F5F0] p-3 rounded-xl border border-[#E5E0D8] mb-4">
          <img
            src={selectedVariant?.image || product.image}
            alt={product.name}
            className="w-16 h-16 rounded-lg object-cover border border-[#E5E0D8] shrink-0 bg-white"
          />
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-bold text-[#111111] truncate">
              {language === 'hi' ? product.nameHi : product.name}
            </h3>
            <div className="flex items-center gap-2 text-xs text-[#4A4A4A] mt-1">
              <span className="font-bold text-[#111111] bg-white border border-[#E5E0D8] px-2 py-0.5 rounded text-[11px]">
                Size: {selectedLength.label.split('-')[0].trim()}
              </span>
              <span className="font-medium text-[#777777] text-[11px]">
                ({selectedLength.suitableFor})
              </span>
            </div>
            <div className="flex items-center justify-between mt-1 text-xs">
              <span className="text-[#777777]">{language === 'hi' ? 'मात्रा:' : 'Qty:'} {quantity}</span>
              <span className="font-extrabold text-[#111111] text-sm">₹{itemPrice}</span>
            </div>
          </div>
        </div>

        {/* Current Cart Summary */}
        <div className="bg-[#F7F5F0] p-3 rounded-xl border border-[#E5E0D8] flex items-center justify-between text-xs mb-5">
          <span className="text-[#4A4A4A] font-medium">
            {language === 'hi' 
              ? `कुल कार्ट: ${cartCount} कपड़े` 
              : `Total Cart: ${cartCount} items`}
          </span>
          <span className="font-black text-[#111111] text-sm">
            {language === 'hi' ? 'कुल:' : 'Subtotal:'} ₹{cartTotal}
          </span>
        </div>

        {/* Two Clear Choices - Golden Rule */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            onClick={handleContinue}
            className="w-full py-3 px-4 rounded-xl border border-[#E5E0D8] bg-white hover:bg-[#F7F5F0] text-[#111111] font-bold text-sm text-center transition cursor-pointer order-2 sm:order-1"
          >
            {language === 'hi' ? 'और कपड़े देखें' : 'Continue Shopping'}
          </button>

          <button
            onClick={handleViewCart}
            className="w-full py-3 px-4 rounded-xl bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold text-sm flex items-center justify-center gap-2 transition shadow-md cursor-pointer order-1 sm:order-2 active:scale-95"
          >
            <span>{language === 'hi' ? 'कार्ट देखें' : 'View Cart'}</span>
            <ArrowRight className="w-4 h-4 text-[#C8A96B]" />
          </button>
        </div>
      </div>
    </div>
  );
};
