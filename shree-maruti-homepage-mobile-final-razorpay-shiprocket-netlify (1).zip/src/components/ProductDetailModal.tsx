import React, { useState } from 'react';
import { Product, ProductVariant, FabricLengthOption } from '../types';
import { useShop } from '../context/ShopContext';
import { 
  X, 
  Star, 
  ShoppingBag, 
  Zap, 
  Check, 
  Info, 
  Ruler, 
  Truck, 
  ShieldCheck, 
  MessageCircle,
  Sparkles
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose }) => {
  const { language, addToCart, openModal } = useShop();

  const defaultVariant: ProductVariant = product.variants?.[0] || {
    id: 'std',
    colorName: 'Standard',
    hex: '#333333',
    image: product.image,
    stock: product.totalStock || 100
  };

  const [selectedLength, setSelectedLength] = useState<FabricLengthOption>(() => {
    // Default to 1.2m if available, or first length option
    const found1_2 = product.lengthOptions.find(opt => opt.lengthMeters === 1.2);
    return found1_2 || product.lengthOptions[0];
  });
  const [quantity, setQuantity] = useState<number>(1);
  const [activeImage, setActiveImage] = useState<string>(product.image);

  // Dynamic price based on length multiplier
  const effectivePrice = Math.round(product.discountPrice * selectedLength.priceMultiplier);
  const effectiveMRP = Math.round(product.originalPrice * selectedLength.priceMultiplier);
  const savings = (effectiveMRP - effectivePrice) * quantity;

  const handleAddToCart = () => {
    addToCart(product, defaultVariant, selectedLength, quantity);
    onClose();
  };

  const handleBuyNow = () => {
    addToCart(product, defaultVariant, selectedLength, quantity);
    onClose();
    // Directly launch checkout for 1-tap shopping flow!
    setTimeout(() => {
      openModal('checkout');
    }, 200);
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello Shree Maruti Krupa, I want to inquire about: ${product.name} (Cut/Size: ${selectedLength.label.split('-')[0].trim()}). Price: ₹${effectivePrice}.`
    );
    window.open(`https://wa.me/918849756544?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="relative bg-white rounded-2xl max-w-3xl w-full my-auto overflow-hidden shadow-2xl border border-[#E5E0D8]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 w-9 h-9 rounded-full bg-[#F7F5F0] hover:bg-[#E5E0D8] text-[#111111] border border-[#E5E0D8] flex items-center justify-center transition cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 max-h-[85vh] overflow-y-auto">
          {/* Left Column: Image & Thumbnails */}
          <div className="p-4 sm:p-6 bg-[#F7F5F0] flex flex-col justify-between border-b md:border-b-0 md:border-r border-[#E5E0D8]">
            <div>
              <div className="relative aspect-square rounded-xl overflow-hidden bg-white border border-[#E5E0D8] shadow-2xs mb-3">
                <img
                  src={activeImage || product.image}
                  alt={product.name}
                  className="w-full h-full object-cover object-center"
                />
                <span className="absolute bottom-2 right-2 bg-[#111111]/90 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-1 rounded-md border border-[#2B2B2B]">
                  Size: <span className="text-[#C8A96B]">{selectedLength.label.split('-')[0].trim()}</span>
                </span>
              </div>

              {/* Thumbnails if available */}
              {product.additionalImages && product.additionalImages.length > 0 && (
                <div className="flex gap-2">
                  <button
                    onClick={() => setActiveImage(product.image)}
                    className={`w-14 h-14 rounded-lg overflow-hidden border-2 cursor-pointer transition ${
                      activeImage === product.image ? 'border-[#111111]' : 'border-[#E5E0D8]'
                    }`}
                  >
                    <img src={product.image} alt="" className="w-full h-full object-cover" />
                  </button>
                  {product.additionalImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImage(img)}
                      className={`w-14 h-14 rounded-lg overflow-hidden border-2 cursor-pointer transition ${
                        activeImage === img ? 'border-[#111111]' : 'border-[#E5E0D8]'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Guarantees */}
            <div className="mt-4 pt-4 border-t border-[#E5E0D8] space-y-2 text-xs text-[#4A4A4A]">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#C8A96B] shrink-0" />
                <span>{language === 'hi' ? 'घर पर पैसे दें (Cash on Delivery)' : 'Cash on Delivery Available'}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#C8A96B] shrink-0" />
                <span>{language === 'hi' ? '7 दिनों में आसान वापसी की सुविधा' : '7 Days Hassle-Free Returns'}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Variant & Buying Controls */}
          <div className="p-4 sm:p-6 flex flex-col justify-between bg-white">
            <div className="space-y-4">
              {/* Brand and Name */}
              <div>
                <span className="text-xs font-bold text-[#777777] uppercase tracking-wider">
                  {product.brand}
                </span>
                <h2 className="text-lg sm:text-xl font-bold text-[#111111] leading-snug mt-0.5">
                  {language === 'hi' ? product.nameHi : product.name}
                </h2>

                <div className="flex items-center gap-2 mt-1.5">
                  <div className="flex items-center gap-1 bg-[#F7F5F0] border border-[#E5E0D8] px-2 py-0.5 rounded text-[#111111] font-bold text-xs">
                    <Star className="w-3.5 h-3.5 fill-[#C8A96B] text-[#C8A96B]" />
                    <span>{product.rating}</span>
                  </div>
                  <span className="text-xs text-[#777777]">
                    {product.reviewCount} {language === 'hi' ? 'ग्राहकों ने सराहा' : 'verified reviews'}
                  </span>
                </div>
              </div>

              {/* Price Details */}
              <div className="p-3 bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl">
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-[#111111]">
                    ₹{effectivePrice * quantity}
                  </span>
                  <span className="text-sm text-[#777777] line-through">
                    ₹{effectiveMRP * quantity}
                  </span>
                  <span className="bg-[#9B2C2C] text-white text-xs font-bold px-2 py-0.5 rounded">
                    {product.discountPercent}% OFF
                  </span>
                </div>
                <p className="text-xs text-[#9B2C2C] font-semibold mt-1">
                  ✓ {language === 'hi' ? `आपकी बचत: ₹${savings}` : `You save ₹${savings} on this order`}
                </p>
              </div>

              {/* Select Fabric Size (Length Cuts) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-[#111111] uppercase tracking-wide flex items-center gap-1.5">
                    <Ruler className="w-3.5 h-3.5 text-[#C8A96B]" />
                    <span>{language === 'hi' ? 'कपड़े की साइज (Fabric Size):' : 'Fabric Size / Cut:'}</span>
                  </label>
                  <span className="text-[11px] text-[#111111] font-semibold bg-[#F7F5F0] px-2.5 py-0.5 rounded-md border border-[#E5E0D8]">
                    {selectedLength.label.split('-')[0].trim()}
                  </span>
                </div>

                <div className="space-y-2">
                  {product.lengthOptions.map((opt, idx) => {
                    const isSelected = selectedLength.label === opt.label || selectedLength.lengthMeters === opt.lengthMeters;
                    const optPrice = Math.round(product.discountPrice * opt.priceMultiplier);
                    const optMRP = Math.round(product.originalPrice * opt.priceMultiplier);
                    return (
                      <button
                        key={idx}
                        onClick={() => setSelectedLength(opt)}
                        className={`w-full text-left p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'border-[#111111] bg-[#F7F5F0] text-[#111111] ring-2 ring-[#111111] shadow-2xs'
                            : 'border-[#E5E0D8] bg-white text-[#4A4A4A] hover:border-[#C8A96B]'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <div className="text-xs sm:text-sm font-bold flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded text-[11px] font-extrabold ${isSelected ? 'bg-[#111111] text-white' : 'bg-[#F7F5F0] text-[#111111] border border-[#E5E0D8]'}`}>
                              {opt.label.split('-')[0].trim()}
                            </span>
                            <span className="truncate">{opt.suitableFor || opt.label}</span>
                            {isSelected && <Check className="w-4 h-4 text-[#C8A96B] shrink-0" />}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-sm font-extrabold text-[#111111] block">
                            ₹{optPrice}
                          </span>
                          <span className="text-[10px] text-[#777777] line-through">
                            ₹{optMRP}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 3: Quantity */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-xs font-bold text-[#111111] uppercase tracking-wide">
                  {language === 'hi' ? 'मात्रा (Quantity):' : 'Quantity:'}
                </span>
                <div className="flex items-center border border-[#E5E0D8] rounded-xl overflow-hidden bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1.5 text-[#111111] hover:bg-[#F7F5F0] font-bold transition cursor-pointer text-sm"
                  >
                    -
                  </button>
                  <span className="px-4 py-1.5 text-xs font-bold text-[#111111] min-w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1.5 text-[#111111] hover:bg-[#F7F5F0] font-bold transition cursor-pointer text-sm"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-5 space-y-2 mt-4 border-t border-[#E5E0D8]">
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={handleAddToCart}
                  className="w-full bg-[#F7F5F0] hover:bg-[#E5E0D8] text-[#111111] font-bold py-3 px-3 rounded-xl text-sm flex items-center justify-center gap-2 transition active:scale-95 border border-[#E5E0D8] hover:border-[#C8A96B] cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4 text-[#C8A96B]" />
                  <span>{language === 'hi' ? 'कार्ट में डालें' : 'Add to Cart'}</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3 px-3 rounded-xl text-sm flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shadow-md"
                >
                  <Zap className="w-4 h-4 text-[#C8A96B] fill-[#C8A96B]" />
                  <span>{language === 'hi' ? 'सीधे खरीदें (Buy Now)' : 'Buy Now'}</span>
                </button>
              </div>

              {/* WhatsApp Support Link */}
              <button
                onClick={handleWhatsApp}
                className="w-full text-center text-xs text-[#4A4A4A] hover:text-[#111111] font-semibold py-1 flex items-center justify-center gap-1.5 cursor-pointer transition"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#C8A96B]" />
                <span>{language === 'hi' ? 'व्हाट्सएप पर इस कपड़े के बारे में पूछें' : 'Ask about this fabric on WhatsApp'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
