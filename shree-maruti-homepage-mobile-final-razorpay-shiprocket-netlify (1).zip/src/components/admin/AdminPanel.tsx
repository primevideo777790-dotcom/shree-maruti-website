import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { AdminLogin } from './AdminLogin';
import { AdminHeader } from './AdminHeader';
import { AdminSidebar, AdminTab } from './AdminSidebar';
import { AdminDashboardView } from './AdminDashboardView';
import { AdminOrdersView } from './AdminOrdersView';
import { AdminProductsView } from './AdminProductsView';
import { AdminReturnsView } from './AdminReturnsView';
import { AdminCustomersView } from './AdminCustomersView';
import { AdminSettingsView } from './AdminSettingsView';
import { AdminAddProductModal } from './AdminAddProductModal';

export const AdminPanel: React.FC = () => {
  const { adminSession } = useShop();

  const [activeTab, setActiveTabState] = useState<AdminTab>(() => {
    try {
      const saved = localStorage.getItem('smk_admin_tab') as AdminTab;
      return (saved && ['dashboard', 'orders', 'products', 'returns', 'customers', 'settings'].includes(saved))
        ? saved
        : 'dashboard';
    } catch {
      return 'dashboard';
    }
  });

  const setActiveTab = (tab: AdminTab) => {
    setActiveTabState(tab);
    try {
      localStorage.setItem('smk_admin_tab', tab);
    } catch {}
  };

  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);

  // If not authenticated as ADMIN, strictly enforce login screen
  if (!adminSession || adminSession.role !== 'ADMIN') {
    return <AdminLogin />;
  }

  return (
    <div className="min-h-screen bg-[#151515] text-[#D9D4CA] flex flex-col font-sans selection:bg-[#C8A96B]/30 selection:text-white">
      {/* Admin Top Header */}
      <AdminHeader onSelectTab={setActiveTab} />

      {/* Main Content Area with Sidebar */}
      <div className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto">
        <AdminSidebar 
          activeTab={activeTab} 
          onSelectTab={setActiveTab} 
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <AdminDashboardView
              onSelectTab={setActiveTab}
              onOpenAddProductModal={() => setIsAddProductModalOpen(true)}
              onViewOrderDetails={() => setActiveTab('orders')}
            />
          )}

          {activeTab === 'orders' && <AdminOrdersView />}

          {activeTab === 'products' && (
            <AdminProductsView
              onOpenAddModal={() => setIsAddProductModalOpen(true)}
            />
          )}

          {activeTab === 'returns' && <AdminReturnsView />}

          {activeTab === 'customers' && <AdminCustomersView />}

          {activeTab === 'settings' && <AdminSettingsView />}
        </main>
      </div>

      {/* Add Product Modal */}
      {isAddProductModalOpen && (
        <AdminAddProductModal onClose={() => setIsAddProductModalOpen(false)} />
      )}
    </div>
  );
};
