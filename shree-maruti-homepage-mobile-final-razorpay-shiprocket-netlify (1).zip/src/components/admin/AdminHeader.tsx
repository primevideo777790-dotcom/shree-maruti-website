import React from 'react';
import { useShop } from '../../context/ShopContext';
import { 
  Scissors, 
  Store, 
  LogOut, 
  Bell, 
  AlertTriangle, 
  ShieldCheck, 
  ExternalLink,
  RotateCcw
} from 'lucide-react';

interface AdminHeaderProps {
  onSelectTab: (tab: 'dashboard' | 'orders' | 'products' | 'returns' | 'customers' | 'settings') => void;
}

export const AdminHeader: React.FC<AdminHeaderProps> = ({ onSelectTab }) => {
  const { adminSession, logoutAdmin, adminStats, navigate } = useShop();

  return (
    <header className="bg-[#111111] border-b border-[#2B2B2B] text-white sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#1E1E1E] border border-[#2B2B2B] text-[#C8A96B] flex items-center justify-center shadow-md">
            <Scissors className="w-5 h-5 -rotate-45" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif font-black text-base text-white tracking-wide">
                SHREE MARUTI KRUPA
              </span>
              <span className="bg-[#2B2B2B] text-[#C8A96B] text-[10px] font-extrabold uppercase px-2 py-0.5 rounded border border-[#C8A96B]/30">
                Admin
              </span>
            </div>
            <p className="text-[11px] text-[#777777]">Store Operations & Order Management • Surat</p>
          </div>
        </div>

        {/* Center: Live Alert Badges */}
        <div className="hidden md:flex items-center gap-3">
          {adminStats.lowStockCount > 0 && (
            <button
              onClick={() => onSelectTab('products')}
              className="flex items-center gap-1.5 bg-[#9B2C2C]/20 border border-[#9B2C2C]/40 text-[#D9D4CA] text-xs px-2.5 py-1 rounded-lg hover:bg-[#9B2C2C]/30 transition cursor-pointer"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-[#9B2C2C]" />
              <span>{adminStats.lowStockCount} Low Stock Items</span>
            </button>
          )}

          {adminStats.returnRequests > 0 && (
            <button
              onClick={() => onSelectTab('returns')}
              className="flex items-center gap-1.5 bg-[#1E1E1E] border border-[#2B2B2B] text-[#C8A96B] text-xs px-2.5 py-1 rounded-lg hover:bg-[#2B2B2B] transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{adminStats.returnRequests} Returns Pending</span>
            </button>
          )}
        </div>

        {/* Right: Quick Storefront Switch & Admin User */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-1.5 bg-[#1E1E1E] hover:bg-[#2B2B2B] text-white border border-[#2B2B2B] hover:border-[#C8A96B]/50 px-3.5 py-2 rounded-xl text-xs font-bold shadow-md transition cursor-pointer active:scale-95"
            title="Open customer storefront in shop mode"
          >
            <Store className="w-4 h-4 text-[#C8A96B]" />
            <span>🛍️ View Storefront</span>
            <ExternalLink className="w-3 h-3 text-[#C8A96B] hidden sm:inline" />
          </button>

          <div className="hidden sm:flex items-center gap-2 border-l border-[#2B2B2B] pl-3">
            <div className="w-8 h-8 rounded-full bg-[#1E1E1E] border border-[#2B2B2B] flex items-center justify-center text-xs font-bold text-[#C8A96B]">
              {adminSession?.username?.charAt(0).toUpperCase() || 'A'}
            </div>
            <div className="text-left text-xs">
              <span className="font-bold text-[#D9D4CA] block leading-tight">
                {adminSession?.username || 'Admin'}
              </span>
              <span className="text-[10px] text-[#777777] font-mono">Store Manager</span>
            </div>
          </div>

          <button
            onClick={logoutAdmin}
            className="p-2 rounded-xl bg-[#1E1E1E] hover:bg-[#2B2B2B] text-[#777777] hover:text-[#9B2C2C] border border-[#2B2B2B] transition cursor-pointer"
            title="Sign out of Admin Session"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
