import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { 
  Users, 
  Search, 
  Phone, 
  MessageCircle, 
  MapPin, 
  Calendar, 
  ShoppingBag, 
  IndianRupee 
} from 'lucide-react';

export const AdminCustomersView: React.FC = () => {
  const { customersList } = useShop();
  const [search, setSearch] = useState('');

  const filtered = customersList.filter(c => {
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      return (
        c.fullName.toLowerCase().includes(q) ||
        c.phoneNumber.includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.state.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-stone-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-serif">
            Customer Directory
          </h1>
          <p className="text-xs text-stone-400 mt-0.5">
            Total {customersList.length} verified buyers • 1-click WhatsApp and call contact
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, phone, city..."
            className="w-full pl-9 pr-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
          />
        </div>
      </div>

      <div className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-sm">
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-stone-400 text-xs">
            <Users className="w-10 h-10 text-stone-600 mx-auto mb-2" />
            <p className="font-bold text-stone-300">No customers found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-950 text-stone-400 text-[11px] uppercase tracking-wider border-b border-stone-800">
                <tr>
                  <th className="py-3 px-4">Customer Name</th>
                  <th className="py-3 px-4">Mobile Number</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Total Orders</th>
                  <th className="py-3 px-4">Total Spend</th>
                  <th className="py-3 px-4">Last Order</th>
                  <th className="py-3 px-4 text-right">Quick Contact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/80 text-stone-300">
                {filtered.map((c) => (
                  <tr key={c.phoneNumber} className="hover:bg-stone-850/60 transition">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-amber-900/60 text-amber-200 flex items-center justify-center font-bold text-xs">
                          {c.fullName.charAt(0).toUpperCase()}
                        </div>
                        <span className="font-bold text-white text-xs">{c.fullName}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono text-stone-300">
                      +91 {c.phoneNumber}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="flex items-center gap-1 text-stone-300">
                        <MapPin className="w-3 h-3 text-stone-500" />
                        {c.city}, {c.state}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="bg-stone-800 text-stone-200 font-bold px-2 py-0.5 rounded text-[11px]">
                        {c.totalOrders} {c.totalOrders === 1 ? 'order' : 'orders'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-bold text-amber-400">
                      ₹{c.totalSpent.toLocaleString('en-IN')}
                    </td>

                    <td className="py-3.5 px-4 text-stone-400 text-[11px]">
                      {c.lastOrderDate}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <a
                          href={`https://wa.me/91${c.phoneNumber}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 hover:bg-emerald-900 transition"
                          title="Message on WhatsApp"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                        </a>
                        <a
                          href={`tel:${c.phoneNumber}`}
                          className="p-1.5 rounded-lg bg-stone-800 text-stone-300 border border-stone-700 hover:bg-stone-700 transition"
                          title="Call Customer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
