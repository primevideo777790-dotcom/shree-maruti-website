import React from 'react';
import { useShop } from '../../context/ShopContext';
import { 
  LayoutDashboard, 
  Package, 
  Shirt, 
  RotateCcw, 
  Users, 
  Settings, 
  AlertTriangle 
} from 'lucide-react';

export type AdminTab = 'dashboard' | 'orders' | 'products' | 'returns' | 'customers' | 'settings';

interface AdminSidebarProps {
  activeTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({ activeTab, onSelectTab }) => {
  const { adminStats, orders, returnRequests } = useShop();

  const menuItems: { id: AdminTab; label: string; subLabel: string; icon: React.ReactNode; badge?: number; badgeColor?: string }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      subLabel: 'Overview & Analytics',
      icon: <LayoutDashboard className="w-5 h-5" />
    },
    {
      id: 'orders',
      label: 'Order Management',
      subLabel: 'Orders & Dispatch',
      icon: <Package className="w-5 h-5" />,
      badge: orders.length,
      badgeColor: 'bg-stone-700 text-stone-200'
    },
    {
      id: 'products',
      label: 'Fabrics & Stock',
      subLabel: 'Catalog & Inventory',
      icon: <Shirt className="w-5 h-5" />,
      badge: adminStats.lowStockCount > 0 ? adminStats.lowStockCount : undefined,
      badgeColor: 'bg-orange-800 text-orange-200'
    },
    {
      id: 'returns',
      label: 'Returns & Refunds',
      subLabel: 'Requests & Settlements',
      icon: <RotateCcw className="w-5 h-5" />,
      badge: adminStats.returnRequests > 0 ? adminStats.returnRequests : undefined,
      badgeColor: 'bg-amber-800 text-amber-200'
    },
    {
      id: 'customers',
      label: 'Customer Directory',
      subLabel: 'Verified Buyers List',
      icon: <Users className="w-5 h-5" />
    },
    {
      id: 'settings',
      label: 'Store Settings',
      subLabel: 'Security & Profile',
      icon: <Settings className="w-5 h-5" />
    }
  ];

  return (
    <aside className="w-full lg:w-64 bg-[#111111] border-b lg:border-b-0 lg:border-r border-[#2B2B2B] p-3 sm:p-4 shrink-0">
      <div className="flex lg:flex-col gap-1.5 overflow-x-auto lg:overflow-visible pb-1 lg:pb-0 scrollbar-none">
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition whitespace-nowrap lg:whitespace-normal cursor-pointer ${
                isActive
                  ? 'bg-[#1E1E1E] text-white border border-[#C8A96B]/40 shadow-sm'
                  : 'text-[#D9D4CA]/70 hover:text-white hover:bg-[#1E1E1E]/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className={isActive ? 'text-[#C8A96B]' : 'text-[#777777]'}>
                  {item.icon}
                </span>
                <div className="text-left leading-tight">
                  <span className="block text-xs sm:text-sm font-bold">{item.label}</span>
                  <span className="text-[10px] text-[#777777] font-normal hidden lg:block">{item.subLabel}</span>
                </div>
              </div>

              {item.badge !== undefined && (
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ml-2 shrink-0 ${
                  isActive ? 'bg-[#111111] text-[#C8A96B] border border-[#C8A96B]/30' : item.badgeColor
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </aside>
  );
};
