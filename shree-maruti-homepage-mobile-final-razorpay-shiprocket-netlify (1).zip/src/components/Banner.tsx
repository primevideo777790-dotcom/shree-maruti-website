import React from 'react';
import { useShop } from '../context/ShopContext';
import { ArrowRight } from 'lucide-react';

export const Banner: React.FC = () => {
  const { setSelectedCategory, language, products } = useShop();

  const shirt = products.find(p => p.category === 'shirt');
  const pant = products.find(p => p.category === 'pant');

  const go = (category: 'shirt' | 'pant' | 'combo') => {
    setSelectedCategory(category);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <section className="smk-premium-hero w-full">
        <button
          type="button"
          onClick={() => go('combo')}
          aria-label="Shop men's premium shirts"
          className="group block w-full cursor-pointer bg-[#111111] text-left"
        >
          <picture>
            <source media="(max-width: 640px)" srcSet="/assets/premium-home-hero-mobile.jpg" />
            <img
              src="/assets/premium-home-hero-desktop.png"
              alt="Men's Premium Shirts"
              className="block w-full h-auto object-cover transition-transform duration-500 group-hover:scale-[1.01]"
            />
          </picture>
        </button>
      </section>

      {/* Mobile reference-style collection section */}
      <section className="smk-mobile-collection bg-white py-7 px-3">
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="h-px w-20 bg-[#D7D2CA]" />
          <span className="text-[11px] tracking-[0.35em] text-[#A0A0A0] uppercase">Our Collection</span>
          <span className="h-px w-20 bg-[#D7D2CA]" />
        </div>
        <h2 className="text-center font-serif text-[28px] leading-tight tracking-tight text-[#111111] mb-5">
          Shop By Category
        </h2>

        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => go('shirt')} className="relative overflow-hidden rounded-xl aspect-[1.18] bg-[#222] text-left group">
            {shirt && <img src={shirt.image} alt="Shirts" className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
            <div className="absolute left-4 bottom-3 text-white flex items-center gap-3">
              <span className="text-xl font-medium tracking-wide">SHIRTS</span><ArrowRight className="w-5 h-5" />
            </div>
          </button>
          <button onClick={() => go('pant')} className="relative overflow-hidden rounded-xl aspect-[1.18] bg-[#222] text-left group">
            {pant && <img src={pant.image} alt="Pants" className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
            <div className="absolute left-4 bottom-3 text-white flex items-center gap-3">
              <span className="text-xl font-medium tracking-wide">PANTS</span><ArrowRight className="w-5 h-5" />
            </div>
          </button>
        </div>
      </section>
    </>
  );
};
